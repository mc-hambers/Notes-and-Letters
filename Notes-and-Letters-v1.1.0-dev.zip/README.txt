Copyright (C) 2026 Maxmc.
Original code is GPL-3.0-or-later. See LICENSE.txt for terms and warranty disclaimer.
Matching complete source archive: Notes-and-Letters-v1.1.0-source.zip
Source release: https://github.com/mc-hambers/Notes-and-Letters/releases/tag/v1.1.0
