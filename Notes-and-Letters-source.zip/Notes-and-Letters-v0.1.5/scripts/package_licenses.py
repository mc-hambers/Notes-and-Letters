"""Attach license notices and the matching source ZIP without changing game files.

Usage: python package_licenses.py RUNTIME.zip SOURCE.zip --output OUTPUT.zip
No network access, game installation, or Nexus account changes are performed.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import tempfile
import zipfile

WORKSPACE = Path(__file__).resolve().parents[1]
GPL = WORKSPACE / 'COPYING.txt'
if not GPL.is_file():
    GPL = WORKSPACE / 'Pickpocketing-Loot/COPYING.txt'


def package(runtime, source, output=None):
    runtime, source = Path(runtime).resolve(), Path(source).resolve()
    output = Path(output).resolve() if output else runtime
    assert runtime != source and output != source
    output.parent.mkdir(parents=True, exist_ok=True)
    license_bytes = GPL.read_bytes()
    assert b'GNU GENERAL PUBLIC LICENSE' in license_bytes and b'END OF TERMS AND CONDITIONS' in license_bytes
    source_name = 'Source/' + source.name
    notice = f'''Copyright (C) 2026 Maxmc

This mod's original code is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by the Free
Software Foundation, either version 3 of the License, or (at your option) any
later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with
this program. If not, see <https://www.gnu.org/licenses/>.

Full license: LICENSE.txt
Corresponding source, dependency sources, build scripts, and original notices:
{source_name}

Third-party components retain their original copyrights and licenses.
CommonLibSSE-NG permissions and exceptions are preserved in the source archive
and reproduced under Third-Party-Licenses. This notice does not relicense any
third-party material. Build tools and game dependencies must be obtained
separately where the included build instructions require them.

This is a packaging-only update. Game files and version numbers are unchanged.
Source and legal notices do not need to be installed into the game Data folder.
Nexus page permissions must separately allow modification and redistribution
under the license terms. This tool does not change the Nexus page.
'''.encode('utf-8')
    with zipfile.ZipFile(source) as src:
        assert src.testzip() is None, 'Corrupt source archive'
        assert any(n.endswith(('.cpp', '.h')) and '/src/' in n for n in src.namelist()), 'Missing mod source'
        assert any('vendor/CommonLibSSE-NG/' in n for n in src.namelist()), 'Missing CommonLib source'
        legal = {}
        for n in src.namelist():
            p = Path(n)
            if p.name.lower().startswith(('license', 'copying', 'copyright', 'exceptions')) or ('/third-party/' in n and not n.endswith('/')) or p.name == 'THIRD_PARTY.md':
                if not n.endswith('/'):
                    # Keep original directory context to distinguish dependency notices.
                    legal['Third-Party-Licenses/' + n] = src.read(n)
    with zipfile.ZipFile(runtime) as original:
        assert original.testzip() is None
        files = {n: original.read(n) for n in original.namelist()
                 if not n.endswith('/') and not n.startswith(('Docs/', 'Source/', 'Third-Party-Licenses/'))
                 and n not in ('LICENSE', 'LICENSE.txt', 'README.txt', 'PACKAGE-CONTENTS.json')}
    manifest = {n: hashlib.sha256(data).hexdigest() for n, data in files.items()}
    manifest[source_name] = hashlib.file_digest(source.open('rb'), 'sha256').hexdigest()
    handle, temporary = tempfile.mkstemp(prefix='licensed-', suffix='.zip', dir=output.parent)
    os.close(handle)
    try:
        with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
            for name, data in files.items(): z.writestr(name, data)
            z.writestr('LICENSE.txt', license_bytes)
            z.writestr('README.txt', notice)
            for name, data in legal.items(): z.writestr(name, data)
            # Source ZIPs are already compressed. Store them without recompression.
            z.write(source, source_name, compress_type=zipfile.ZIP_STORED)
            z.writestr('PACKAGE-CONTENTS.json', json.dumps(manifest, indent=2) + '\n')
        with zipfile.ZipFile(temporary) as z:
            assert z.testzip() is None
            assert len(z.namelist()) == len(set(z.namelist()))
            assert not any(n.startswith('Docs/') for n in z.namelist())
            assert z.read('LICENSE.txt') == license_bytes
            for name, expected in manifest.items():
                with z.open(name) as stream:
                    assert hashlib.file_digest(stream, 'sha256').hexdigest() == expected, name
        os.replace(temporary, output)
    finally:
        if Path(temporary).exists(): Path(temporary).unlink()
    return {'file': str(output), 'bytes': output.stat().st_size,
            'sha256': hashlib.file_digest(output.open('rb'), 'sha256').hexdigest(),
            'unchanged_payload_files': len(files), 'third_party_notices': len(legal),
            'source_archive': str(source), 'zip_integrity': 'passed',
            'runtime_and_source_hashes': 'passed', 'docs_folder': False}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('runtime')
    parser.add_argument('source')
    parser.add_argument('--output')
    args = parser.parse_args()
    print(json.dumps(package(args.runtime, args.source, args.output), indent=2))
