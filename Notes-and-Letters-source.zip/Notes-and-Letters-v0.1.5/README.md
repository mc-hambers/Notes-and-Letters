# Notes and Letters — 0.1.5 development build

An SKSE mod adding small pieces of correspondence to Skyrim. This is an initial development build. Compilation and automated tests have passed; the courier scenes, book rendering, and gameplay triggers still require in-game acceptance testing.

## Requirements and installation

- Skyrim Special Edition or Anniversary Edition, with matching SKSE64 and Address Library for SKSE Plugins.
- Install this archive through your mod manager and enable `NotesAndLetters.esp`. It is ESL-flagged and uses compact local IDs. Keep its filename unchanged.
- Optional and recommended: Courier Delivers to NPCs by Pickysaurus, version 1.0.4 (`WICourierRadiant.esp`), for visible deliveries to supported NPCs: https://www.nexusmods.com/skyrimspecialedition/mods/42928
- Without that optional integration, NPC letters use direct inventory placement. Player letters use Skyrim's vanilla courier.
- Dragonborn supports the Severin Manor letters. Shadowfoot Sanctum must be installed for its house letters; its absence does not block other features.
- No SPID, MCM, or additional dynamic-form framework is used. The DLL supports SE 1.5.97 and the AE runtime versions listed in its runtime guard, including the installed 1.7.104 runtime. Other storefronts/runtimes need separate validation.

No game files or existing companion mods are modified by the build/package tools. Install only when ready to test.

## Authored content

224 original notes have distinct titles: 160 NPC notes, and 64 player letters. The proofreading draft contains their complete text and stable review IDs. `content/notes.json` is the authoritative editable catalog. Run `scripts/build_content.py` and rebuild the DLL after editing it; JSON is build-time source, not a live configuration file. Keep existing note order and IDs stable when updating an existing save.

NPC categories have 20 notes each: romance, condolences, congratulations, gratitude, encouragement, business, welcome, and personal notes/lists. Personal notes and lists never have signatures. Lists contain vanilla item names. Other NPC notes receive varied initials when created; repeated signatures are acceptable. Existing copies keep their chosen text and signature.

Player categories contain 10 spouse letters, 5 jealousy letters, 5 investment letters, 15 friendship letters, 15 hate letters, and 14 house welcomes. The seven houses each have two distinct letters.

## NPC distribution

Living adult NPCs of the ten playable races, their vampire variants, and the elder race are eligible. Children, summons, creatures, dead actors, and the courier are excluded. Active followers remain eligible.

Eligible actor references are discovered without loading their cells. Loaded NPCs and small batches of off-cell references receive an initial roll. Their next refresh is selected once, 3–5 game days later, and checked during loaded or off-cell processing. Loading repeatedly, opening inventory, and reloading a save do not restart a saved timer or grant extra rolls. Missed intervals do not accumulate.

One allowed category is chosen, then a single chance roll is made. The baseline is 2%; occupation modifiers use 1% or 3%. These are not eight independent rolls. Thus actual overall odds vary modestly by occupation. At most one pocket note from this system is outstanding per NPC.

At refresh, a note still in that NPC's inventory has a 50% chance of being removed. A retained note prevents another roll. If there is no note afterward, the NPC can receive one new chance roll. Taken notes remain intact. Inventory resets do not bypass the saved refresh timer.

Supported recipients receive a queued note through Courier Delivers to NPCs. That dependency's delivery quest is tied to the Story Manager and cannot be started with the ordinary quest-start API. This integration uses its existing ten-second preparation window, chooses a waiting recipient in the same settlement before the scene starts, and transfers the actual note during the final spoken phase. Its daytime, location-change, availability, and delivery-frequency conditions remain in force. A successful roll therefore queues delivery rather than guaranteeing an immediate visit.

Queued letters are not discarded before delivery. Their recipient's refresh interval starts afresh when the handoff completes. A recipient who becomes unsupported receives their queued copy directly. The mod never redirects an already-playing scene.

## Occupation modifiers

Roles are assigned from vanilla factions, with conflicts resolved in this order: bandit, guard, beggar, noble, bard, innkeeper, smith, merchant, farmer, hunter, healer/priest, worker, scholar, ordinary. Unmatched NPCs use ordinary odds. Custom faction/class mappings are not yet configurable.

- Romance: beggars and bandits 1%; nobles and bards 3%; other eligible roles 2%.
- Condolences: beggars and bandits 1%; ordinary townspeople, guards, and farmers 3%; others 2%.
- Congratulations: beggars, bandits, and guards 1%; nobles and bards 3%; others 2%.
- Gratitude: beggars and bandits 1%; innkeepers, healers, and merchants 3%; others 2%.
- Encouragement: beggars and bandits 1%; healers, guards, and workers 3%; others 2%.
- Business: merchants, smiths, and innkeepers 3%; farmers and workers 2%; other roles excluded.
- Welcome: innkeepers and farmers 3%; other settled roles 2%; bandits and hunters excluded.
- Personal notes/lists: merchants, scholars, hunters, and workers 3%; others 2%.

## Player letters and initial timing defaults

These conservative defaults fill the probabilities that were not explicitly specified:

- Spouse: 5% every 3–5 days. Any married spouse qualifies, using the vanilla marriage quest. Signed with their first name.
- Jealousy: 1% every 14–21 days. The player must be married; the sender must be a different NPC at Lover relationship rank. Signed with the sender's initial.
- Friendship: 2% every 5–7 days per encountered named friend or better. Signed with a name or initial.
- Hatred: 1% every 7–14 days per encountered named Rival or Foe. Every letter begins with the player's name. It is placed in the sender's inventory for 2–3 days before that exact copy is moved to the vanilla courier's delivery container. Theft, removal, destruction, or the sender's death cancels its delivery. An outstanding draft or player delivery prevents another hate draft from that sender.
- Investment: one 20% roll 2–3 days after a new investment observed by this mod. The vanilla investment statistic and current dialogue merchant identify the event. Older investments are not reconstructed. Merchant name and shop context are captured for the letter; unidentified events are logged and skipped rather than assigned to a guessed merchant.
- House welcomes: one lifetime roll per owned supported home: 85% one letter, 10% both unique letters, 5% none. A named NPC whose editor location places them in the settlement is selected from loaded residents. If no resident is available, the decision waits. Existing owned houses are included on first activation. Letters are signed with the resident's name or initial.

Spouse checks also run when the spouse is away. Other relationship chances are checked when the sender is encountered. Investment delays and staged hate letters continue independently of the sender's loaded state. Courier arrival still follows vanilla delivery conditions.

## Courier's inventory

The courier receives a separate 2–4 note bundle on first activation and every 3–5 days. Only bundle copies still carried by the courier are replaced. Stolen bundle notes remain yours. Pending recipient letters are tracked separately and are not removed by bundle refreshes, so a courier can carry more than four notes when deliveries are waiting.

## Saving and updates

The normal save stores inventories and the SKSE co-save stores note metadata, sender/owner references, signatures, timers, unique-ID changes, house decisions, and delivery state. Load-order FormIDs are remapped. Reloading an older save restores its earlier state. Keep the `.skse` co-save with its matching save file. Missing or corrupt existing records disable distribution rather than silently regenerating items.

Individual books use static light-plugin records and saved extra data; no new dynamic BOOK forms are created. The book-menu hook supplies each saved copy's personalized text. Collected notes therefore require the DLL and their co-save for personalized signatures and addresses. Removing the mod is not an uninstall-supported operation.

## Build and validation

Run `scripts/build_content.py` with Python, then `scripts/build.ps1` with the configured MSVC/vcpkg toolchain. The tool paths can be supplied explicitly. `scripts/package.py` validates the built DLL, records, behavior tests, ZIP integrity, and packaged bytes, then creates an install archive and corresponding source archive.

See `VALIDATION.md` for remaining in-game checks. Logs are written to the Skyrim SKSE log folder as `NotesAndLetters.log`.

## Optional NPC courier and debug mode � 0.1.1

Courier Delivers to NPCs is optional and recommended for visible NPC deliveries. With no integration installed, all successful NPC rolls place notes directly into the recipient's inventory. `NotesAndLetters.esp` has no courier-mod master dependency. Unsupported recipients also use direct placement. Player letters continue to use Skyrim's vanilla courier.

`Data/SKSE/Plugins/NotesAndLetters.ini` contains `UseNPCCourier=true` under `[General]`. Set it to `false` to use direct NPC placement even when the courier integration is installed. Pending copies already on the courier fall back to their intended recipient when that NPC is next processed. Successful fallback handoff starts a fresh 3�5-day refresh interval. These options are read at game startup.

Aim at an NPC in normal gameplay, open the console, then run:

```
NLDebug
NLSpawnNote
```

`NLDebug` toggles debug mode for the current session. Run it again to disable it, or set `Enabled=true` under `[Debug]` in the INI for debug at startup. NLDebug alone adds NPC-check/roll details to `NotesAndLetters.log`; it does not change ordinary chances or timers.

`NLSpawnNote` requires debug mode and a valid loaded save. It uses the crosshair NPC remembered when the console opens, not a stale console selection. It forces a successful NPC pocket-note roll and immediate direct placement, bypassing the ordinary chance and remaining refresh delay. Living-adult/race/creature/courier eligibility, category restrictions, varied signatures, unsigned personal lists, persistence limits, and one-outstanding-pocket-note rules remain. Categories are weighted by the normal 1/2/3-percent chances, matching the mix among normal successful rolls. An existing queued courier note also blocks duplication. Success starts a normal saved 3�5-day refresh timer. This command does not produce player letters or trigger relationship events.

The console reports the target, note title, category/role IDs, and next refresh day, or explains why it could not spawn a note. Command registration checks two unused no-op developer console slots and refuses to replace working or third-party handlers; registration failures are logged. Installed 1.7.104 file mappings are audited, but command execution still needs in-game testing.

Note instance data now reserves at least 32 bytes from Skyrim's heap before native construction, correcting the combined SE/AE facade allocation issue. Save schema and existing note IDs remain unchanged. The install ZIP contains only ESP, DLL, and INI; documentation and licenses are in the source archive.

## Startup fix and repeat testing � 0.1.2

Fixed courier resolution: the vanilla courier is an ACHR actor reference (00039FB7). An exact typed REFR lookup rejected it and prevented all note distribution. Reference resolution now performs an untyped lookup followed by a polymorphic reference cast. Startup logs report each required form and the number of resolved books. Missing forms and invalid saved metadata now produce distinct console diagnostics.

Missing game forms no longer mark an otherwise-readable save payload as corrupt. An old disabled-state record is recovered automatically only if it decodes as completely empty: no NPCs, notes, consumed instance IDs, delivery state, house decisions, or timers. Nonempty invalid data still fails closed. No existing valid note state is reset.

Enable debug with `NLDebug`, then run `NLRepeatNotes` and close the console. This session-only toggle makes effective NPC refresh waits and courier cooldown zero, and forces successful allowed NPC note rolls. Loaded eligible NPCs are checked every 2.5 real seconds. Pending courier copies block duplicate creation; a delivered/current recipient-owned pocket copy is removed before its next replacement, keeping one tracked outstanding copy per NPC. Taken copies are preserved. No player-letter, relationship, investment, house, or bundle timer is accelerated.

With Courier Delivers to NPCs enabled, testing respects its daytime (08:00�20:00), same-settlement, target availability, and vanilla player-delivery exclusions. The courier quest must first be started by its normal Story Manager opportunity: enter or re-enter a suitable settlement during daytime. After that, repeat mode starts a fresh idle delivery scene for waiting recipients, rotating recipients rather than repeatedly selecting the same NPC. The courier is returned to the quest's settlement center if needed; active scenes are never redirected. Failed scene starts retain the queued note and retry. Repeat mode cannot guarantee the underlying Story Manager will grant the first delivery opportunity.

Without the optional integration, the same mode repeatedly replaces pocket notes directly in eligible loaded NPC inventories. Run `NLRepeatNotes` again or turn debug off to restore normal behavior. Loading another save or restarting the game also disables repeat mode. Effective zero waits are not written over all saved NPC deadlines; each newly created note gets an ordinary saved 3�5-day refresh deadline for after testing ends.

One-note testing remains `NLSpawnNote`. No new configuration keys or ESP records are required. The repeat-scene adapter still requires in-game acceptance testing.

## Paper-note preview/opening repair � 0.1.3

All 224 BOOK records now include the vanilla paper-note INAM art link Skyrim.esm|097788 (HighPolyNote), matching a vanilla note that uses the same Clutter/Books/Note01.nif dropped-world model. Their DATA prefix now matches the vanilla record instead of forcing an unused/type byte to FF. INAM supplies the separate high-poly inventory/reading model; the dropped-world MODL alone was insufficient. The package validator requires the correct INAM/model link on every note.

At startup, the DLL also repairs missing INAM links on its own note catalog when vanilla note art is available, preserving already-customized non-null art. Update both DLL and ESP from this package. Existing saved instances retain their IDs, contents, and signatures and do not need regeneration.

The personalized-text hook now reads instance data only on BookMenu's kShow event for owned note records, rather than on every menu message. It no longer processes the movement/investment inbox during the menu callback. Missing instance text falls back to authored base text. Opening-stage logs identify the note and whether its inventory art is present.

The inspected user log established successful startup and note creation in 0.1.2, ending after a forced NPC note; no crash stack was available. The missing art links are confirmed record defects, and the installed BookMenu open-function disassembly matches the globals used by the text hook. Successful build and record validation do not establish a complete runtime crash fix. Previewing and opening notes in game still need retesting.

## Four paper styles, off-cell notes, and explicit deliveries � 0.1.4

Each newly created note randomly chooses one of four clean vanilla paper styles: Note01, Note02, Note03, or Note04. Every style has its matching dropped-world model and high-poly reading/inventory art. The choice is saved per instance, so picking up, transferring, and reloading a note preserves its appearance. There are still 224 distinct authored texts; 896 compact BOOK records provide four stable model variants each. Existing note FormIDs remain unchanged. Schema-1 instances migrate to their existing Note01 model; schema 2 saves the new style and helper route.

Removed the em dash before signatures, which the handwritten font could render as a blank square. Signed notes now use a blank line followed directly by the signature. Personal notes/lists remain unsigned.

The main-thread scan now discovers existing actor references and processes at most 32 off-cell candidates per scan, revisiting discovery periodically. It does not force cell/worldspace loads or create NPCs that the game has not instantiated. Eligibility, saved 3�5-day refreshes, note removal, and one-outstanding-note rules still apply. NPCs outside the visible player area receive direct inventory placement, including different cells/worldspaces. Relationship letter checks remain tied to encounters (apart from the existing spouse behavior).

Courier delivery no longer depends solely on the other mod's first location-change event. A script-free quest/package included in NotesAndLetters.esp can bring the shared courier to a visible supported recipient, use Skyrim's vanilla Follow template to approach, and transfer the exact queued note on arrival. If the external NPC courier quest is preparing/playing a scene, the helper yields and the adapter uses that scene. Active vanilla player deliveries and combat take priority. Failed/unreachable approaches preserve the note for retry. The helper handoff is an AI approach and inventory transfer, not a newly voiced conversation. The optional courier integration remains required for visible NPC courier routing; without it, notes use direct placement.

For one courier test, aim at a named adult in a settlement, open the console, run `NLDebug` if debug is off, then `NLDeliverNote`. Close the console to allow AI and delivery processing. `NLSpawnNote` deliberately remains a direct inventory test; it does not summon a courier. Ineligible-for-courier targets fall back to direct placement. Existing pending pocket notes block duplicate test notes. `NLRepeatNotes` now uses the same explicit helper whenever a natural delivery scene is unavailable. Normal helper deliveries retain daytime and cooldown restrictions; repeat mode bypasses those waits for testing.

Install both updated ESP and DLL. Keep the matching SKSE co-save. These model, remote inventory, AI approach, interruption, and scene handoff changes require in-game validation; successful automated tests do not establish live delivery success.

## Courier delivery event replacement � 0.1.5

The previous native scene adapter and custom courier Follow quest/package implementation are removed. Notes and Letters no longer retargets the external quest's aliases, reads SceneStarted, monitors scene phases, starts/restarts scenes, or operates a courier movement/package loop. Two inert old FormIDs remain solely for save compatibility; the retired quest is stopped on game entry and no longer contains actor aliases or packages.

Install the main Notes-and-Letters-v0.1.5-dev.zip normally. For visible NPC deliveries, also install Notes-and-Letters-Courier-Event-v0.1.5.zip and enable NotesAndLetters-CourierEvent.esp after WICourierRadiant.esp. The optional ESL-flagged patch appends one new NL_NPCNoteDelivery script to the existing courier quest, retaining the original scripts/properties, aliases, conditions, stages, and scene. It adds no dependency to the base NotesAndLetters.esp and does not overwrite the installed courier mod or its original scripts.

The new event is OnNLDeliverNote(Actor Recipient, Int RequestID). Notes and Letters queues one actual note on the courier, then sends the event. The handler yields to busy/player deliveries and normal NPC scenes, enables/positions the courier if needed, and uses Skyrim's latent PathToReference to approach the recipient. It reports Ready, Failed, or Busy through a mod callback. Only a validated Ready callback transfers the exact tracked note, preserving its saved text, signature, and paper model. Failed/busy requests keep the queued copy for retry. The event does not start the scoped quest or change its scene/aliases. The handoff is a simple approach and inventory transfer, without a new voiced conversation.

Without both the courier mod and the event attachment, notes fall back to direct NPC inventory placement. The native DLL checks for the bound event script and logs whether it is available. The courier still carries the separate 2�4 random-note bundle, refreshed every 3�5 days; pending deliveries are kept separate.

Testing commands are unchanged: NLDebug, NLDeliverNote for a courier request, NLSpawnNote for direct placement, and NLRepeatNotes for repeat testing. Close the console to let pathing run. Existing pending notes prevent duplicates. Normal chances/timers resume when repeat testing is disabled. Save schema 2 and all note/model IDs remain unchanged.

The optional patch is built against the installed Courier Delivers to NPCs 1.0.4 quest layout. As with any quest override, other changes to the same quest require a merged patch. Build and record checks are complete; event binding, real movement/handoff, interruption, and save/load still require in-game acceptance tests.
