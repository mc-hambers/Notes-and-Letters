# Validation — development build 0.1.5

## Automated evidence

- MSVC Release x64 DLL builds against CommonLibSSE-NG for combined SE/AE.
- Native core behavior checks cover refresh boundaries, interval ranges, bounded occupation probabilities, category exclusions, saved text/signatures/timers, complete and truncated serialization, repeat hate-draft prevention, stolen/dead sender cancellation, and unique-item ID rebinding without changing note identity.
- Catalog validation checks 224 distinct IDs, titles and bodies; exact category counts; unsigned personal notes; player-name openings for hate letters; and list entries against a vanilla-item allowlist.
- Packaging verifies ESL flags, compact local BOOK IDs, valid record/subrecord lengths, authored titles/text, DLL architecture and SKSE metadata, archive integrity, and exact packaged DLL/ESP bytes.
- All extracted dependency scripts and records remain local research material and are excluded from distributed archives. The dependency mod is not bundled or overwritten.

## Required in-game acceptance tests

These have not been run. A successful compile is not proof that Skyrim courier scenes or UI hooks work.

1. Load an existing save with its matching SKSE co-save. Check all catalog/forms resolve in `NotesAndLetters.log`; test a new game separately.
2. Read multiple copies of the same signed note, including from NPC inventory, player inventory, containers, and dropped world references. Confirm distinct saved signatures, no placeholder text, and correct text after save/load and changing load order.
3. Read personal lists/reflections from all those contexts. Confirm no signature line at all and correct line breaks.
4. Exercise a natural Courier Delivers to NPCs preparation window with a queued recipient. Confirm alias assignment finishes before the scene, the final phase is observed, and exactly one actual note moves from courier to recipient. Interrupt with combat, dialogue, cell changes, save/load, and scene cancellation. Confirm no duplicate handoff or permanently stuck delivery.
5. Confirm unsupported guards/bandits receive direct inventory notes and supported NPCs use delivery. Test without the optional courier integration as well.
6. Re-enter cells repeatedly before 3 days. Confirm no timer restart or extra rolls. Advance past a saved refresh deadline. Confirm retained notes block stacking and only the intended NPC's own note can disappear. Test a true inventory reset and stolen note.
7. Inspect and steal the courier's bundle, then advance past its refresh. Confirm 2–4 bundle notes, pending delivery copies preserved, and stolen notes unaffected.
8. Generate a hate draft with a named Rival/Foe. Check the actual player name is first. Wait 2–3 game days and confirm that exact copy reaches the vanilla delivery container and is delivered. Repeat after stealing, dropping, selling, or destroying the draft and after the sender dies. Confirm no replacement is sent for the canceled draft.
9. Test married spouses of both sexes and a different Lover-ranked NPC; verify names, initials, eligibility, and saved intervals. Test friend/rival changes and absence from loaded cells.
10. Invest through vanilla dialogue. Confirm the event identifies the right merchant and shop once, then one 20% roll occurs 2–3 days later. Modded merchant dialogues need separate compatibility testing.
11. Test the five vanilla houses, Severin Manor, and optional Shadowfoot Sanctum. Confirm actual cell ownership, resident selection, two distinct house texts, one saved decision per house, and no repeat on reload. Localization and Shadowfoot cell discovery need verification on an installation containing that Creation.
12. Test alongside Dynamic Pickpocket Loot, NPCs Have Ammo, courier overhauls, and other book-menu hooks. Check both mods' logs and actual inventories, not compilation alone.

## Known validation limits

The initial courier adapter targets Courier Delivers to NPCs 1.0.4's script and scene layout. Other versions or replacements require their own audit. It deliberately uses natural Story Manager opportunities; queued NPC notes may wait for travel/daytime rather than trigger an immediate courier spawn.

House ownership, the investment-stat event's dialogue target, and book-menu personalization are engine integration points still awaiting runtime proof. Shadowfoot Sanctum was not installed in the inspected game, so its optional cell discovery has not been exercised. Content is English.

## 0.1.1 optional courier and debug validation

Automated checks include optional-routing combinations, debug mode/active/eligible/outstanding gates, valid category selection for every occupation, INI defaults/parsing/invalid values, no-op command-slot signature checks, and a simulated 32-byte native constructor with an allocation guard. DLL metadata and install payload checks now include version 0.1.1 and the INI. The ESP header is checked to exclude a WICourierRadiant master.

Still required in game: start without Courier Delivers to NPCs; aim at an eligible adult, open the console, run NLDebug and NLSpawnNote, inspect the actual note, and retry to confirm duplicate rejection. Test children, creatures, dead actors, the courier, and an empty crosshair. Close the console, change targets, and verify the command follows the new crosshair. Test the normal 3�5-day refresh and save/load of the forced note. Test normal distribution without the integration, with it installed, and with UseNPCCourier=false. Verify previously queued notes fall back once without duplication when the recipient loads. Debug registration and console output are not proven by file audits or compilation.

## 0.1.2 startup/repeat evidence

The inspected 0.1.1 log reported Catalog resolved=false before the command was used. Read-only Skyrim.esm inspection confirms the required courier 00039FB7 is ACHR, whereas the container 00039FB9 is REFR. Regression fixtures reproduce rejection by exact-type lookup and acceptance by polymorphic reference resolution. Required-form failures are separated from save decoding failures. Tests cover recovery of strictly empty legacy state and rejection of states with prior actor/instance/timer/delivery/house activity, and effective zero-delay refresh without overwriting the original saved deadline.

New repeat command registration uses OutputMemStats only when it remains an untouched no-op handler. The installed executable previously showed B0 01 C3 at that handler. Repeat mode retains one pending note per NPC, forces categories conditional on ordinary success, skips the half-day courier cooldown, and uses Scene.Start through the VM only on an idle scene of an already-running courier quest. It does not synthesize location events or bypass Story Manager startup. Runtime tests are still required for activation, first natural quest start, repeated scene starts, final-phase transfers, recipient rotation, timeout recovery, mode-off behavior, and save/load.

## 0.1.3 preview/read crash audit

Read-only Skyrim.esm inspection: vanilla dunLabyrinthianMazeClue 00108160 uses MODL Clutter/Books/Note01.nif, DATA prefix 0000, and INAM 00097788. That INAM is STAT HighPolyNote with model Clutter/Books/Note01/Note01.nif. Earlier generated notes omitted INAM entirely and used DATA prefix 00FF. All generated records now require the vanilla paper-note art and prefix, and package checks validate every note's INAM and model.

Read-only installed 1.7.104 OpenMenu function (Address Library 51053, RVA 0x907290) writes description at RVA 0x3255C58, extra list at 0x3255C38, and target book at 0x3255C40, matching the linked CommonLib getters. The text hook is restricted to kShow and owned notes; it leaves unrelated books and other messages alone. No crash stack was present in the inspected SKSE log locations, so this does not prove there are no other crash causes.

Required runtime checks: install both new DLL and ESP; preview the note in NPC/player/container inventories, open it, close/reopen it, transfer and drop/read it, and reload a saved personalized copy. Confirm the preview mesh, readable body/signature, unsigned lists, no crash on close/hide, and unchanged vanilla book behavior. Repeat with existing notes and new NLSpawnNote instances.

## 0.1.4 validation

Read-only vanilla records confirm all four world-model/INAM pairs. The helper package uses the vanilla Follow template 00019B2C with a recipient-alias input and a helper quest containing only forced reference aliases. Package validation checks all 896 BOOK records, model pairings, 224 unique authored titles, compact FormIDs, and the helper quest/package cross references. No courier-mod master dependency is introduced.

Regression tests cover schema-1 note-text/signature migration, stable saved model choices, model-index rejection, helper-route consistency, and the plain signature footer. Existing serializer truncation and distribution tests remain. Off-cell snapshots release the global form-map lock before inventory operations. Remote processing is bounded to 32 references per scan.

Required gameplay: generate varied model copies and check preview/read/drop/reload; verify existing signature text no longer shows the square; wait for notes on a known NPC in another cell/worldspace; test NLDeliverNote on a supported named recipient with no active external courier quest; verify courier movement, correct-recipient arrival transfer, no duplicate note, timeout retry, vanilla courier priority, and interruption/save-load recovery. Test repeat mode, direct fallback without the optional integration, and active external courier scenes. No live success is claimed.

## 0.1.5 event-only courier replacement

Native code inspection confirms removal of all old alias, scene-start/phase, courier movement, and Follow-package delivery code. Generated legacy compatibility records contain no active aliases or package template. The base plugin still has no WICourierRadiant master. Optional patch generation reads the installed plugin without modification, preserves every non-VMAD quest field byte-for-byte, preserves the original VMAD scripts and fragment tail, and appends only NL_NPCNoteDelivery. The patch's master order retains the original record references.

Caprica compiles the new handler against minimal compile-only native interfaces. Only its own PEX is distributed, never replacement Form/Quest/Actor scripts or original courier scripts. Interface headers and script source are in the source archive. Callback-ID tests cover exact representability of all note keys in Papyrus float mod-event arguments and rejection of invalid numeric arguments. Existing note persistence, models, category, and refresh checks pass.

Required runtime checks: main mod without optional patch must place notes directly; with both patch and NPC courier mod, startup must log event availability. NLDeliverNote must create one pending copy, send OnNLDeliverNote, receive a matching callback, and transfer that copy after arrival. Test busy/player deliveries, original NPC scene priority, failure retry, taking the queued copy, different recipients, repeat mode, and save/load during pathing. Confirm 2�4 random courier bundle notes remain independent of actual requests. None of these runtime checks have been performed by this build.
