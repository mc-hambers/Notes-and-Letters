# Notes and Letters — Complete Proofreading Draft

224 notes: 160 NPC notes and 64 player letters. Draft 1.

Each heading contains a stable review ID and the unique in-game note title. Use the ID when requesting edits. Text beneath the heading is the complete note body.

Braced text is a runtime placeholder, not literal in-game text. NPC signatures are chosen per note instance; repeats are acceptable. Personal notes and lists have no signature. Player letters use the appropriate sender. House welcomes are signed by a resident of the relevant settlement.

NPC notes are self-contained flavor: no quests, rewards, appointments, requests, or specific off-page actions. Personal lists are fragments rather than instructions. Player letters refer only to their stated relationship, investment, or home ownership context.

## Contents

- NPC notes: eight categories, 20 each.
- Player letters: lover 10, jealousy 5, investment 5, friendship 15, hatred 15, house welcomes 14.

## NPC Notes — 160

### Love and Romance Notes (20)

#### NPC-L01 — A Quiet Confession

I love you. These few words hold more than all the fine phrases I could find.

— {random_signature}

#### NPC-L02 — Dear to Me

You are dearer to me than I know how to explain.

— {random_signature}

#### NPC-L03 — A Tender Thought

There is a tenderness in my heart that belongs to you alone.

— {random_signature}

#### NPC-L04 — A Familiar Smile

The thought of your smile makes the world feel kinder.

— {random_signature}

#### NPC-L05 — Poor Words

My words are clumsy, but my affection is sincere.

— {random_signature}

#### NPC-L06 — Simple Happiness

Loving you is a quiet happiness, and a precious one.

— {random_signature}

#### NPC-L07 — A Warm Heart

Even in the coldest season, my love for you feels warm.

— {random_signature}

#### NPC-L08 — Still Yours

My affection is steady, even when words are difficult.

— {random_signature}

#### NPC-L09 — Near in Thought

You are close to my heart, however distant everything else may feel.

— {random_signature}

#### NPC-L10 — A Shy Confession

I am shy about love, but certain of what I feel for you.

— {random_signature}

#### NPC-L11 — Quiet Comfort

The thought of you is a comfort I cannot quite put into words.

— {random_signature}

#### NPC-L12 — Ordinary Love

My love needs no grand tale to make it true.

— {random_signature}

#### NPC-L13 — Loved Deeply

You are loved deeply. That is all this little note means to say.

— {random_signature}

#### NPC-L14 — A Foolish Heart

My heart is rather foolish where you are concerned. I am fond of it for that.

— {random_signature}

#### NPC-L15 — Lasting Affection

Some feelings are too dear for the passing of days to diminish.

— {random_signature}

#### NPC-L16 — An Unadorned Truth

I love you without a finer way to say it.

— {random_signature}

#### NPC-L17 — A Heart at Ease

My heart feels at ease in its affection for you.

— {random_signature}

#### NPC-L18 — Dear Beyond Reason

You are dear to me beyond any sensible accounting.

— {random_signature}

#### NPC-L19 — A Certain Feeling

Of all my uncertain thoughts, my love for you is the surest.

— {random_signature}

#### NPC-L20 — Tenderly Yours

There is nothing grand in these words, only tenderness for you.

— {random_signature}

### Sympathy and Condolence Notes (20)

#### NPC-S01 — Deepest Sympathy

I am deeply sorry for your loss. My sympathy is with you.

— {random_signature}

#### NPC-S02 — No Right Words

There are no perfect words for grief, only sincere ones. These are mine.

— {random_signature}

#### NPC-S03 — A Dear Memory

May the memory of someone dear hold a little gentleness amid the sorrow.

— {random_signature}

#### NPC-S04 — In Sorrow

My heart aches for you in this time of mourning.

— {random_signature}

#### NPC-S05 — Grief Has No Measure

Grief has no proper measure. Your sorrow is worthy of compassion.

— {random_signature}

#### NPC-S06 — Kindly Remembered

A life held dear remains precious in memory.

— {random_signature}

#### NPC-S07 — The Weight of Loss

Loss can feel terribly heavy. You have my deepest sympathy.

— {random_signature}

#### NPC-S08 — Shared Sadness

Your sorrow matters to me, though I cannot make it smaller with words.

— {random_signature}

#### NPC-S09 — Gentle Thoughts

These are gentle thoughts for a heart burdened by loss.

— {random_signature}

#### NPC-S10 — Love and Absence

The absence of someone loved can be painful beyond words.

— {random_signature}

#### NPC-S11 — A Small Condolence

This small note holds sincere condolences and nothing demanded of you.

— {random_signature}

#### NPC-S12 — A Dear Life

Someone dear to you deserves to be remembered with affection.

— {random_signature}

#### NPC-S13 — Through Sorrow

May there be some comfort within the sorrow, however faint.

— {random_signature}

#### NPC-S14 — Quiet Sympathy

My sympathy is quiet, but no less heartfelt for that.

— {random_signature}

#### NPC-S15 — Not Forgotten

What a person means to us does not end with their life.

— {random_signature}

#### NPC-S16 — A Gentle Memory

May remembrance be gentle with you in your grief.

— {random_signature}

#### NPC-S17 — Words Beside Sorrow

These words cannot mend your loss, but they hold my sympathy.

— {random_signature}

#### NPC-S18 — A Life Remembered

A cherished life leaves something precious in the hearts of others.

— {random_signature}

#### NPC-S19 — With Compassion

You have my compassion in this painful time.

— {random_signature}

#### NPC-S20 — Room for Grief

There is no shame in sorrow for someone dearly loved.

— {random_signature}

### Congratulations and Milestone Notes (20)

#### NPC-C01 — Another Year

Happy birthday. May this new year of your life be a kind one.

— {random_signature}

#### NPC-C02 — A Happy Milestone

Congratulations on this milestone. It deserves a little pride.

— {random_signature}

#### NPC-C03 — Wedding Wishes

Warm congratulations to you both. May your marriage hold much happiness.

— {random_signature}

#### NPC-C04 — A New Arrival

Congratulations on the little one. My warmest wishes to your family.

— {random_signature}

#### NPC-C05 — Well Deserved

Congratulations. Your happiness is well deserved.

— {random_signature}

#### NPC-C06 — Good Fortune

What happy news. May your good fortune be lasting.

— {random_signature}

#### NPC-C07 — A Proud Moment

This is a moment worthy of pride. Congratulations.

— {random_signature}

#### NPC-C08 — A Happy Occasion

Warm wishes on this happy occasion. May the joy of it be yours.

— {random_signature}

#### NPC-C09 — Many Years Together

Happy anniversary. A lasting love is a lovely thing.

— {random_signature}

#### NPC-C10 — Birthday Wishes

A very happy birthday to someone much valued.

— {random_signature}

#### NPC-C11 — A Fresh Chapter

Congratulations on this new chapter. May it hold contentment.

— {random_signature}

#### NPC-C12 — A Well-Earned Rest

Warm congratulations on your retirement. May it be peaceful and satisfying.

— {random_signature}

#### NPC-C13 — Simple Congratulations

Congratulations, sincerely and wholeheartedly.

— {random_signature}

#### NPC-C14 — A Reason for Joy

Your good news is a reason for joy. My warmest congratulations.

— {random_signature}

#### NPC-C15 — A New Beginning

Best wishes for this new beginning. May it be a happy one.

— {random_signature}

#### NPC-C16 — A Birthday Blessing

May your birthday hold warmth, contentment, and a little laughter.

— {random_signature}

#### NPC-C17 — Joy in Small Letters

These small letters carry wholehearted congratulations.

— {random_signature}

#### NPC-C18 — A Year Worth Marking

Another year of your life is something worth celebrating.

— {random_signature}

#### NPC-C19 — Well-Earned Pride

May you feel the pride that this happy milestone deserves.

— {random_signature}

#### NPC-C20 — Happiness to You

My warmest congratulations, and much happiness to you.

— {random_signature}

### Thank-You Notes (20)

#### NPC-T01 — Much Valued

You are valued more than this small note can express.

— {random_signature}

#### NPC-T02 — Quiet Gratitude

My gratitude is sincere, even when my words are plain.

— {random_signature}

#### NPC-T03 — Old Friends

Your friendship is among the good things in my life.

— {random_signature}

#### NPC-T04 — Kind at Heart

Your kindness is something I deeply appreciate.

— {random_signature}

#### NPC-T05 — A Good Friend

I am grateful to call you a friend.

— {random_signature}

#### NPC-T06 — Warm Appreciation

These few words hold a great deal of appreciation.

— {random_signature}

#### NPC-T07 — More Than Words

My thanks are greater than my skill at putting them on paper.

— {random_signature}

#### NPC-T08 — A Dear Friend

A dear friend is a rare comfort. You are one to me.

— {random_signature}

#### NPC-T09 — Remembered Fondly

You are thought of with affection and gratitude.

— {random_signature}

#### NPC-T10 — Honest Thanks

No fine phrasing, only honest thanks and warm regard.

— {random_signature}

#### NPC-T11 — Good in the World

The world feels a little better for having people like you in it.

— {random_signature}

#### NPC-T12 — Small Words

Thank you. Small words, but heartfelt ones.

— {random_signature}

#### NPC-T13 — No Occasion Needed

There need be no special occasion to say that you matter to me.

— {random_signature}

#### NPC-T14 — A Grateful Heart

There is a grateful place in my heart with your name upon it.

— {random_signature}

#### NPC-T15 — Glad of You

I am glad that you are part of my life.

— {random_signature}

#### NPC-T16 — Friendship on Paper

Your friendship deserves these few words of appreciation.

— {random_signature}

#### NPC-T17 — Simply Appreciated

You are appreciated, simply and sincerely.

— {random_signature}

#### NPC-T18 — A Rare Kindness

Kindness such as yours is a rare and welcome thing.

— {random_signature}

#### NPC-T19 — A Small Tribute

This is a small expression of gratitude for a friendship I hold dear.

— {random_signature}

#### NPC-T20 — Warmly Valued

You have my thanks, my affection, and my warm regard.

— {random_signature}

### Get-Well and Encouragement Notes (20)

#### NPC-G01 — Healing Wishes

My warmest wishes for your recovery.

— {random_signature}

#### NPC-G02 — A Little Comfort

May these few words offer a little comfort while you are unwell.

— {random_signature}

#### NPC-G03 — Better Days

I hope gentler days and renewed strength are ahead of you.

— {random_signature}

#### NPC-G04 — Worthy of Kindness

You are worthy of kindness, especially when life feels difficult.

— {random_signature}

#### NPC-G05 — Still Valued

A difficult time does not make you any less valued.

— {random_signature}

#### NPC-G06 — A Slow Recovery

Recovery can feel slow. My hopes for your healing are sincere.

— {random_signature}

#### NPC-G07 — Strength Within

There is more to you than this illness or hardship.

— {random_signature}

#### NPC-G08 — In Hard Times

My thoughts are with you in this difficult time.

— {random_signature}

#### NPC-G09 — A Gentle Hope

May your heart feel a little lighter and your body a little stronger.

— {random_signature}

#### NPC-G10 — Faith in You

I believe in you, even when confidence feels far away.

— {random_signature}

#### NPC-G11 — No Measure of Worth

Your worth is not measured by how quickly you recover.

— {random_signature}

#### NPC-G12 — Peaceful Wishes

Wishing you ease, peace, and healing.

— {random_signature}

#### NPC-G13 — A Setback

A difficult day does not make all hope meaningless.

— {random_signature}

#### NPC-G14 — Dear to Others

You remain dear to others through hardship as much as through happiness.

— {random_signature}

#### NPC-G15 — Quiet Encouragement

This is a small expression of encouragement, offered with affection.

— {random_signature}

#### NPC-G16 — A Kinder Morning

May a kinder morning feel nearer than it does today.

— {random_signature}

#### NPC-G17 — Strength Without Hurry

Your strength need not be hurried to be real.

— {random_signature}

#### NPC-G18 — More Than a Hard Day

You are more than the weight of a difficult day.

— {random_signature}

#### NPC-G19 — Hope in Plain Words

I hope you find comfort, steadiness, and renewed strength.

— {random_signature}

#### NPC-G20 — A Patient Wish

May recovery be gentle, however long it takes.

— {random_signature}

### Business and Client Notes (20)

#### NPC-B01 — Valued Custom

Your custom is sincerely appreciated.

— {random_signature}

#### NPC-B02 — Respectful Regards

You have my respectful regards and sincere appreciation for your trade.

— {random_signature}

#### NPC-B03 — A Good Reputation

A reputation for fairness is something worthy of respect.

— {random_signature}

#### NPC-B04 — Honest Trade

Honest trade has a value beyond the coins involved.

— {random_signature}

#### NPC-B05 — Mutual Respect

Mutual respect is a fine foundation for any business relationship.

— {random_signature}

#### NPC-B06 — Plain Appreciation

A plain note of appreciation for a valued customer.

— {random_signature}

#### NPC-B07 — Pride in Craft

Good craftsmanship deserves recognition and respect.

— {random_signature}

#### NPC-B08 — Fair Dealing

Fair dealing is a quality I admire greatly.

— {random_signature}

#### NPC-B09 — Valued Trust

Your trust means a great deal.

— {random_signature}

#### NPC-B10 — Sound Work

There is dignity in sound work, however humble the craft.

— {random_signature}

#### NPC-B11 — A Fellow Tradesperson

My respectful regards to a fellow tradesperson.

— {random_signature}

#### NPC-B12 — Good Standing

Your good name is held in high regard.

— {random_signature}

#### NPC-B13 — Worthy Skill

Skill and care are worthy of appreciation.

— {random_signature}

#### NPC-B14 — Good Wishes

My best wishes for your prosperity and contentment.

— {random_signature}

#### NPC-B15 — Honest Measures

Honesty in trade is a quiet virtue, and an important one.

— {random_signature}

#### NPC-B16 — Respect for a Craft

There is much to respect in a craft practiced with care.

— {random_signature}

#### NPC-B17 — A Customer's Regard

My regard for your trade is sincere.

— {random_signature}

#### NPC-B18 — Worth More Than Coin

Fairness and courtesy have a worth beyond coin.

— {random_signature}

#### NPC-B19 — A Tradesperson's Esteem

You have the esteem of a fellow tradesperson.

— {random_signature}

#### NPC-B20 — The Value of Care

Care in one's work is a fine thing to be known for.

— {random_signature}

### Welcome Notes (20)

#### NPC-W01 — A New Neighbor

A warm welcome to a new neighbor.

— {random_signature}

#### NPC-W02 — Among Colleagues

You are a welcome addition among your colleagues.

— {random_signature}

#### NPC-W03 — A Sense of Belonging

May you feel a sense of belonging here.

— {random_signature}

#### NPC-W04 — Settling In

Warm wishes as you settle into unfamiliar surroundings.

— {random_signature}

#### NPC-W05 — A Kindly Welcome

This little note holds a kindly welcome and sincere goodwill.

— {random_signature}

#### NPC-W06 — Among Friends

May unfamiliar faces soon feel less unfamiliar.

— {random_signature}

#### NPC-W07 — Glad You Are Here

We are glad you are here. A simple welcome, sincerely meant.

— {random_signature}

#### NPC-W08 — A Comfortable Home

May your new home feel comfortable and peaceful.

— {random_signature}

#### NPC-W09 — Part of the Community

You are a valued new part of this community.

— {random_signature}

#### NPC-W10 — Warm Regards

Warm regards and a heartfelt welcome.

— {random_signature}

#### NPC-W11 — Finding Your Feet

May the unfamiliar feel a little more comfortable with time.

— {random_signature}

#### NPC-W12 — A Quiet Welcome

A quiet welcome can be just as heartfelt as a grand one.

— {random_signature}

#### NPC-W13 — Room to Belong

There is room for you to belong here.

— {random_signature}

#### NPC-W14 — A Friendly Beginning

May this beginning feel friendly and full of possibility.

— {random_signature}

#### NPC-W15 — A Good Beginning

A warm welcome, and good wishes for the days ahead.

— {random_signature}

#### NPC-W16 — A Place Among Us

May there be comfort in feeling that you have a place among us.

— {random_signature}

#### NPC-W17 — New Faces, Warm Wishes

A warm welcome, and sincere wishes for your contentment.

— {random_signature}

#### NPC-W18 — Kindly Neighbors

May the thought of kindly neighbors make this place feel warmer.

— {random_signature}

#### NPC-W19 — An Easy Beginning

A warm welcome, with wishes for an easy beginning.

— {random_signature}

#### NPC-W20 — Familiar in Time

May these unfamiliar surroundings feel familiar in time.

— {random_signature}

### Personal Lists and Notes (20)

#### NPC-P01 — Pantry List

Salt Pile  
Bread  
Red Apple  
Honey

#### NPC-P02 — Useful Little Things

Lockpick  
Torch  
Leather Strips

#### NPC-P03 — Three Good Qualities

Patience, honesty, and a sense of humor. Worth more than fine boots.

#### NPC-P04 — For the Alchemy Shelf

Lavender  
Blue Mountain Flower  
Thistle Branch  
Juniper Berries

#### NPC-P05 — A Modest Wish

A warm room, a sound roof, and enough bread. A modest measure of comfort.

#### NPC-P06 — A Line About Rain

Rain has a different voice on every roof.

#### NPC-P07 — The Shape of a Day

Morning light. Midday noise. Evening quiet.

#### NPC-P08 — Cloth and Leather

Linen Wrap  
Leather  
Leather Strips

#### NPC-P09 — Words Worth Keeping

Enough is a kinder word than more.

#### NPC-P10 — A Short Provision List

Bread  
Goat Cheese Wedge  
Elves Ear  
Nord Mead

#### NPC-P11 — Materials List

Iron Ingot  
Steel Ingot  
Corundum Ingot  
Leather Strips

#### NPC-P12 — A Question on Paper

Is silence still silence when the kettle is singing?

#### NPC-P13 — Food and Drink

Sweet Roll  
Honey Nut Treat  
Boiled Creme Treat  
Alto Wine

#### NPC-P14 — A Verse of Pines

The hills are gray, the sky is wide;  
The pines stand dark on either side.

#### NPC-P15 — A List of Ingredients

Frost Mirriam  
Garlic  
Juniper Berries  
Snowberries

#### NPC-P16 — A Small Supply List

Torch  
Lockpick  
Potion of Minor Healing

#### NPC-P17 — On Good Sense

A little good sense is less showy than a fine hat and rather more useful.

#### NPC-P18 — A Weather Thought

Snow makes even a familiar road look like a new thought.

#### NPC-P19 — Things for the Table

Wooden Plate  
Wooden Bowl  
Tankard

#### NPC-P20 — A Pleasant Sound

A kettle, a hearth, and rain against a shutter. A fine little orchestra.

## Player Letters — 64

### Lover Notes (10)

#### PLAYER-LOVE01 — My Dearest

Being married to you is a quiet joy that these words can barely hold.

— {spouse_first_name}

#### PLAYER-LOVE02 — Always Dear

Whatever the day may hold, you are dear to me.

— {spouse_first_name}

#### PLAYER-LOVE03 — A Spouse's Affection

This is a small note from the person who is glad to be your spouse.

— {spouse_first_name}

#### PLAYER-LOVE04 — A Heart Beside Yours

My heart is happy to be beside yours in marriage.

— {spouse_first_name}

#### PLAYER-LOVE05 — Our Quiet Happiness

There is a quiet happiness in calling you my beloved.

— {spouse_first_name}

#### PLAYER-LOVE06 — Few Words, Much Love

Few words today: I love you, and I am glad of us.

— {spouse_first_name}

#### PLAYER-LOVE07 — A Familiar Tenderness

My affection for you feels as familiar and welcome as warmth.

— {spouse_first_name}

#### PLAYER-LOVE08 — Dearer Still

You are dear to me in ways that fine words never quite explain.

— {spouse_first_name}

#### PLAYER-LOVE09 — Glad to Be Yours

I am glad to be your spouse. It is a simple thing, and a precious one.

— {spouse_first_name}

#### PLAYER-LOVE10 — Love Without Finery

No fine verse, only love from the person you married.

— {spouse_first_name}

### Jealousy Notes (5)

#### PLAYER-JEAL01 — An Unquiet Heart

You are married, and not to me. My heart has made poor peace with that.

— {other_lover_initial}

#### PLAYER-JEAL02 — A Bitter Little Truth

I wish your marriage did not trouble me. It does.

— {other_lover_initial}

#### PLAYER-JEAL03 — Someone Else's Vows

Your vows belong to someone else. My affection is rather less sensible.

— {other_lover_initial}

#### PLAYER-JEAL04 — An Unwelcome Feeling

Jealousy is an ugly feeling. Knowing that has not made mine smaller.

— {other_lover_initial}

#### PLAYER-JEAL05 — A Quiet Envy

I envy the person who can call you their spouse. There is little dignity in how I feel.

— {other_lover_initial}

### Investment Notes (5)

#### PLAYER-INV01 — Confidence in Our Trade

Your investment in {shop} is appreciated. Confidence in a small business has a value beyond coin.

— {merchant_name}, {shop}

#### PLAYER-INV02 — A Merchant's Gratitude

Thank you for investing in {shop}. You have my sincere appreciation and professional regard.

— {merchant_name}, {shop}

#### PLAYER-INV03 — Worthy of Trust

I am grateful for your investment in {shop}. It is an honor for my trade to be thought worthy of that trust.

— {merchant_name}, {shop}

#### PLAYER-INV04 — A Shopkeeper's Thanks

A plain note of thanks for your investment in {shop}. Your confidence means a great deal.

— {merchant_name}, {shop}

#### PLAYER-INV05 — Respect and Appreciation

Your investment in {shop} deserves these few words of appreciation. You have my respect as well as my thanks.

— {merchant_name}, {shop}

### Thank-You Notes (15)

#### PLAYER-FRIEND01 — A Friend's Regard

Your friendship is one of the good things in my life.

— {friend_name_or_initial}

#### PLAYER-FRIEND02 — Glad to Know You

I am glad to know you. No particular occasion is needed to say so.

— {friend_name_or_initial}

#### PLAYER-FRIEND03 — A Valued Friendship

A friendship such as yours is something I value greatly.

— {friend_name_or_initial}

#### PLAYER-FRIEND04 — Few Words of Thanks

These are few words, but my appreciation for you is sincere.

— {friend_name_or_initial}

#### PLAYER-FRIEND05 — Dear as a Friend

You are dear to me as a friend, and worthy of these plain words.

— {friend_name_or_initial}

#### PLAYER-FRIEND06 — A Kindly Thought

The thought of your friendship makes the world feel a little kinder.

— {friend_name_or_initial}

#### PLAYER-FRIEND07 — Friendship Enough

Your friendship is reason enough for a grateful note.

— {friend_name_or_initial}

#### PLAYER-FRIEND08 — A Good Person

It is a comfort to count a good person among one's friends.

— {friend_name_or_initial}

#### PLAYER-FRIEND09 — Appreciation in Ink

A little ink is a poor measure of how much I appreciate you.

— {friend_name_or_initial}

#### PLAYER-FRIEND10 — A Friend Well Valued

You are a friend well valued, however seldom I put it into words.

— {friend_name_or_initial}

#### PLAYER-FRIEND11 — Honest Affection

These words hold honest affection and a friend's gratitude.

— {friend_name_or_initial}

#### PLAYER-FRIEND12 — A Quiet Thank You

A quiet thank you for being someone I am glad to call a friend.

— {friend_name_or_initial}

#### PLAYER-FRIEND13 — Warm Regard

You have my warm regard and sincere appreciation.

— {friend_name_or_initial}

#### PLAYER-FRIEND14 — No Grand Occasion

There is no grand occasion behind this note. I simply value your friendship.

— {friend_name_or_initial}

#### PLAYER-FRIEND15 — A Good Thing in Life

Of the good things in life, your friendship is among the dearest.

— {friend_name_or_initial}

### I Hate You Notes (15)

#### PLAYER-HATE01 — Plain Dislike

{player_name},  
  
I dislike you. A short note is quite enough for that truth.

— {rival_name_or_initial}

#### PLAYER-HATE02 — No Warm Regard

{player_name},  
  
You have none of my affection and little of my respect.

— {rival_name_or_initial}

#### PLAYER-HATE03 — A Bitter Opinion

{player_name},  
  
My opinion of you is poor, and these words are its plain expression.

— {rival_name_or_initial}

#### PLAYER-HATE04 — No Fondness

{player_name},  
  
I feel no fondness for you. I find that unusually easy to put into words.

— {rival_name_or_initial}

#### PLAYER-HATE05 — An Honest Contempt

{player_name},  
  
These few lines contain honest contempt and no courtesy worth mentioning.

— {rival_name_or_initial}

#### PLAYER-HATE06 — Thoroughly Unimpressed

{player_name},  
  
I am thoroughly unimpressed by you, and rather tired of the thought of you.

— {rival_name_or_initial}

#### PLAYER-HATE07 — A Cold Regard

{player_name},  
  
My regard for you is as cold as a stone in deep winter.

— {rival_name_or_initial}

#### PLAYER-HATE08 — Little to Admire

{player_name},  
  
I find very little about you to admire.

— {rival_name_or_initial}

#### PLAYER-HATE09 — A Sour Sentiment

{player_name},  
  
You inspire a sour sentiment that even good ink cannot improve.

— {rival_name_or_initial}

#### PLAYER-HATE10 — Without Affection

{player_name},  
  
This note is entirely without affection. That is its chief virtue.

— {rival_name_or_initial}

#### PLAYER-HATE11 — Without Pretense

{player_name},  
  
My dislike of you is quite sincere. I have no wish to dress it in polite words.

— {rival_name_or_initial}

#### PLAYER-HATE12 — A Poor Impression

{player_name},  
  
You have made a poor impression upon my heart and an even poorer one upon my patience.

— {rival_name_or_initial}

#### PLAYER-HATE13 — Undiminished Disdain

{player_name},  
  
My disdain for you remains undiminished.

— {rival_name_or_initial}

#### PLAYER-HATE14 — No Kind Opinion

{player_name},  
  
There is no kind opinion of you concealed between these lines.

— {rival_name_or_initial}

#### PLAYER-HATE15 — An Unpleasant Thought

{player_name},  
  
The thought of you is an unpleasant one. This note is no warmer.

— {rival_name_or_initial}

### House Welcome: Breezehome (2)

#### PLAYER-BREEZE01 — A Welcome to Breezehome

A warm welcome to Breezehome. May your corner of Whiterun feel comfortable and your hearth feel like your own.

— {local_resident_name_or_initial}

#### PLAYER-BREEZE02 — A Place in Whiterun

Breezehome is a fine name for a new beginning. Welcome to a home beneath Whiterun's open sky.

— {local_resident_name_or_initial}

### House Welcome: Honeyside (2)

#### PLAYER-HONEY01 — Welcome Beside the Water

Welcome to Honeyside. May your home in Riften hold a little of the peace suggested by its place beside the water.

— {local_resident_name_or_initial}

#### PLAYER-HONEY02 — A Riften Neighbor

A warm welcome to Honeyside, and to a place among Riften's neighbors. May the rooms feel truly yours.

— {local_resident_name_or_initial}

### House Welcome: Vlindrel Hall (2)

#### PLAYER-VLINDREL01 — A Home Among Stone

Welcome to Vlindrel Hall. May a home among Markarth's old stone hold plenty of warmth.

— {local_resident_name_or_initial}

#### PLAYER-VLINDREL02 — Warmth in Markarth

Warm wishes for your home in Vlindrel Hall. Even a city of stone has room for a kindly welcome.

— {local_resident_name_or_initial}

### House Welcome: Hjerim (2)

#### PLAYER-HJERIM01 — A Gentle Welcome to Hjerim

Welcome to Hjerim. May your rooms in Windhelm feel peaceful and your hearth warmer than the streets outside.

— {local_resident_name_or_initial}

#### PLAYER-HJERIM02 — A Hearth in Windhelm

A home in Hjerim deserves a warm welcome. May it hold comfort enough for Windhelm's coldest days.

— {local_resident_name_or_initial}

### House Welcome: Proudspire Manor (2)

#### PLAYER-PROUD01 — Welcome to Proudspire

Welcome to Proudspire Manor. May your home in Solitude feel as welcoming within as its name is grand.

— {local_resident_name_or_initial}

#### PLAYER-PROUD02 — A Place in Solitude

Warm wishes for Proudspire Manor, and a neighbor's welcome to your new corner of Solitude.

— {local_resident_name_or_initial}

### House Welcome: Severin Manor (2)

#### PLAYER-SEVERIN01 — A Raven Rock Welcome

A warm welcome to Severin Manor. May your home in Raven Rock feel comfortable beneath the ash-gray sky.

— {local_resident_name_or_initial}

#### PLAYER-SEVERIN02 — Warmth on Solstheim

Welcome to Severin Manor. May these rooms hold a little warmth and belonging on Solstheim.

— {local_resident_name_or_initial}

### House Welcome: Shadowfoot Sanctum (2)

#### PLAYER-SHADOW01 — A Quiet Riften Welcome

Welcome to Shadowfoot Sanctum. May your quiet home beneath Riften feel like a comfortable corner of the world.

— {local_resident_name_or_initial}

#### PLAYER-SHADOW02 — A Home Below the Streets

Warm wishes for Shadowfoot Sanctum. A home below Riften's streets deserves its share of comfort and a kindly welcome.

— {local_resident_name_or_initial}
