Scriptname NL_NPCNoteDelivery extends Quest
; Optional event extension for Courier Delivers to NPCs. Original scripts/quest behavior are retained.
Bool Busy = false

Event OnNLDeliverNote(Actor Recipient, Int RequestID)
    Actor Courier = Game.GetFormFromFile(0x39FB7, "Skyrim.esm") as Actor
    Quest PlayerDelivery = Game.GetFormFromFile(0x39F82, "Skyrim.esm") as Quest
    Scene NormalScene = Game.GetFormFromFile(0x801, "WICourierRadiant.esp") as Scene
    If Busy || !Courier || !Recipient
        SendModEvent("NL_NoteDeliveryBusy", "", RequestID as Float)
        Return
    EndIf
    If Recipient.IsDead() || Recipient.IsDisabled() || !Recipient.Is3DLoaded()
        SendModEvent("NL_NoteDeliveryFailed", "", RequestID as Float)
        Return
    EndIf
    ; Yield while the normal NPC scene is preparing/playing or the player courier is active.
    If PlayerDelivery.IsRunning() || Courier.IsInCombat() || NormalScene.IsPlaying() || (IsRunning() && GetStage() < 200)
        SendModEvent("NL_NoteDeliveryBusy", "", RequestID as Float)
        Return
    EndIf
    Busy = true
    If Courier.GetParentCell() != Recipient.GetParentCell() || Courier.GetDistance(Recipient) > 3000.0
        Courier.MoveTo(Game.GetPlayer())
    EndIf
    Courier.EnableNoWait()
    Bool Arrived = Courier.PathToReference(Recipient, 1.0)
    If Arrived && !Recipient.IsDead() && Courier.GetParentCell() == Recipient.GetParentCell() && Courier.GetDistance(Recipient) < 200.0 && !PlayerDelivery.IsRunning() && !NormalScene.IsPlaying()
        ; Notes and Letters transfers the tracked instance, preserving its signature/model.
        SendModEvent("NL_NoteDeliveryReady", "", RequestID as Float)
    Else
        SendModEvent("NL_NoteDeliveryFailed", "", RequestID as Float)
    EndIf
    If !PlayerDelivery.IsRunning() && !NormalScene.IsPlaying() && !(IsRunning() && GetStage() < 200)
        ObjectReference Marker = Game.GetFormFromFile(0x39FBA, "Skyrim.esm") as ObjectReference
        If Marker
            Courier.MoveTo(Marker)
        EndIf
    EndIf
    Busy = false
EndEvent
