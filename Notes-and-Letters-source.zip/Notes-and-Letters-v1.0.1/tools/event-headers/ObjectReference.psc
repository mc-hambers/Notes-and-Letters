Scriptname ObjectReference extends Form Native Hidden
Function MoveTo(ObjectReference akTarget, float afXOffset = 0.0, float afYOffset = 0.0, float afZOffset = 0.0, bool abMatchRotation = true) native
Function EnableNoWait(bool abFadeIn = false) native
Cell Function GetParentCell() native
float Function GetDistance(ObjectReference akOther) native
bool Function Is3DLoaded() native
bool Function IsDisabled() native
