Scriptname Scene extends Form Native Hidden
bool Function IsPlaying() native
