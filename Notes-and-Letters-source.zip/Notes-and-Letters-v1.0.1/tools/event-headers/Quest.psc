Scriptname Quest extends Form Native Hidden
bool Function IsRunning() native
int Function GetStage() native

; Compile-only declaration of the event dispatched by the SKSE bridge.
Event OnNLDeliverNote(Actor Recipient, Int RequestID)
EndEvent
