Scriptname Form Native Hidden
Function SendModEvent(string eventName, string strArg = "", float numArg = 0.0) native
