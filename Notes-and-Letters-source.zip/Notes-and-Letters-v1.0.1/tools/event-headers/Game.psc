Scriptname Game Native Hidden
Form Function GetFormFromFile(int aiFormID, string asFilename) global native
Actor Function GetPlayer() global native
