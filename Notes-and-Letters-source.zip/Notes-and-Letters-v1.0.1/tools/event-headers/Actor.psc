Scriptname Actor extends ObjectReference Native Hidden
bool Function IsDead() native
bool Function IsInCombat() native
bool Function PathToReference(ObjectReference aTarget, float afWalkRunPercent) native
