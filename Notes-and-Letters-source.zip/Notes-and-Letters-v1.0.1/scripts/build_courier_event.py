"""Build an optional event-only quest override; never change the installed courier mod."""
import struct,zlib,json,subprocess,hashlib
from pathlib import Path
from build_content import sub,text,record
ROOT=Path(__file__).resolve().parents[1]
GAME=Path(r'M:/SteamLibrary/steamapps/common/Skyrim Special Edition/Data')
def fields(raw):
    pos=0
    while pos<len(raw):
        tag,size=struct.unpack_from('<4sH',raw,pos);pos+=6
        assert pos+size<=len(raw);yield tag,raw[pos:pos+size];pos+=size

def add_event_script(raw):
    version,fmt,count=struct.unpack_from('<HHH',raw);assert version==5 and fmt==2
    pos=6;names=[]
    def string():
        nonlocal pos
        size=struct.unpack_from('<H',raw,pos)[0];pos+=2;value=raw[pos:pos+size];pos+=size;return value
    def value(kind):
        nonlocal pos
        if kind==1:pos+=8
        elif kind==2:string()
        elif kind in (3,4):pos+=4
        elif kind==5:pos+=1
        elif kind in (11,12,13,14,15):
            length=struct.unpack_from('<I',raw,pos)[0];pos+=4
            for _ in range(length):value(kind-10)
        else:raise ValueError('Unsupported VMAD value type '+str(kind))
    for _ in range(count):
        names.append(string());pos+=1;props=struct.unpack_from('<H',raw,pos)[0];pos+=2
        for _ in range(props):
            string();kind=raw[pos];pos+=2;value(kind)
    assert b'WICourierRadiantScript' in names and b'NL_NPCNoteDelivery' not in names
    name=b'NL_NPCNoteDelivery';script=struct.pack('<H',len(name))+name+struct.pack('<BH',0,0)
    return struct.pack('<HHH',version,fmt,count+1)+raw[6:pos]+script+raw[pos:]

def main(compiler=None):
    mod=GAME/'WICourierRadiant.esp';masters=[];quest=None
    with mod.open('rb') as stream:
        while header:=stream.read(24):
            tag,size,flags,form=struct.unpack_from('<4sIII',header)
            if tag==b'GRUP':continue
            raw=stream.read(size)
            if flags&0x40000:raw=zlib.decompress(raw[4:])
            if tag==b'TES4':masters=[data.rstrip(b'\0').decode() for key,data in fields(raw) if key==b'MAST']
            if tag==b'QUST' and form&0xFFFFFF==0x800:quest=(header,raw)
    assert masters==['Skyrim.esm','Update.esm','Dragonborn.esm'] and quest
    header,original=quest;original_fields=list(fields(original));assert dict(original_fields)[b'EDID']==b'WICourierNPCs\0'
    replaced=[(tag,add_event_script(data) if tag==b'VMAD' else data) for tag,data in original_fields]
    assert [(t,d) for t,d in replaced if t!=b'VMAD']==[(t,d) for t,d in original_fields if t!=b'VMAD']
    payload=b''.join(sub(tag.decode(),data) for tag,data in replaced)
    patched_header=bytearray(header);struct.pack_into('<I',patched_header,4,len(payload));struct.pack_into('<I',patched_header,8,struct.unpack_from('<I',header,8)[0]&~0x40000)
    assert struct.unpack_from('<I',header,12)[0]==0x03000800
    header_data=sub('HEDR',struct.pack('<fII',1.7,1,0x800))+text('CNAM','Maxmc')+text('SNAM','Optional Notes and Letters delivery-event attachment')
    for master in masters+['WICourierRadiant.esp']:header_data+=text('MAST',master)+sub('DATA',b'\0'*8)
    body=bytes(patched_header)+payload
    plugin=record('TES4',0,header_data,0x200)+struct.pack('<4sI4sIHHHH',b'GRUP',24+len(body),b'QUST',0,0,0,0,0)+body
    out=ROOT/'build/optional';out.mkdir(parents=True,exist_ok=True);(out/'NotesAndLetters-CourierEvent.esp').write_bytes(plugin)
    if compiler is None:
        compiler=ROOT.parent.parent/'g-p-6aa8fdf2a63c8191889973abbdcf06bb/harvestable-flora-regrows/tools/caprica/Caprica.exe'
    subprocess.run([str(compiler),'NL_NPCNoteDelivery.psc','--game','skyrim','--ignorecwd','--import',str(ROOT/'tools/event-headers'),'--flags',str(ROOT/'tools/EventFlags.flg'),'--output',str(out/'Scripts')],cwd=ROOT/'papyrus',check=True)
    pex=(out/'Scripts/NL_NPCNoteDelivery.pex').read_bytes();assert pex[:4] in (bytes.fromhex('FA57C0DE'),bytes.fromhex('DEC057FA'))
    assert b'OnNLDeliverNote' in pex and b'NL_NoteDeliveryReady' in pex
    report=dict(optional_patch='NotesAndLetters-CourierEvent.esp',original_quest_non_script_fields_preserved=True,old_scripts_not_replaced=True,new_script='NL_NPCNoteDelivery',event='OnNLDeliverNote',compiler='Caprica',original_plugin_sha256=hashlib.sha256(mod.read_bytes()).hexdigest(),gameplay_tested=False)
    (ROOT/'research/courier-event-validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));return report
if __name__=='__main__':main()
