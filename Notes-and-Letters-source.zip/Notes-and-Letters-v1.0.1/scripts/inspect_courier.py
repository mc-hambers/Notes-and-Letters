"""Read-only dependency inspection. Extracts script assets into this project's research folder."""
import json
import struct
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
GAME = Path(r'M:\SteamLibrary\steamapps\common\Skyrim Special Edition\Data')
def subrecords(data):
    pos=0
    extended=None
    while pos+6<=len(data):
        tag,size=struct.unpack_from('<4sH',data,pos)
        pos+=6
        if tag==b'XXXX':
            extended=struct.unpack_from('<I',data,pos)[0]
            pos+=size
            continue
        size=extended if extended is not None else size
        extended=None
        if pos+size>len(data):raise ValueError('Invalid subrecord')
        yield tag,data[pos:pos+size]
        pos+=size

def strings(data):
    import re
    return [s.decode('ascii') for s in re.findall(rb'[ -~]{4,}', data)]

def inspect_plugin():
    rows = []
    with (GAME / 'WICourierRadiant.esp').open('rb') as stream:
        while header := stream.read(24):
            tag, size, flags, form = struct.unpack_from('<4sIII', header)
            if tag == b'GRUP':
                continue
            data = stream.read(size)
            if flags & 0x40000:
                data = zlib.decompress(data[4:])
            rows.append(dict(type=tag.decode(), form=f'{form:08X}', fields=[dict(tag=t.decode(),hex=b.hex(),strings=strings(b)) for t,b in subrecords(data)]))
    (ROOT / 'research/courier-records.json').write_text(json.dumps(rows, indent=2), encoding='utf-8')
    for r in rows:
        if r['type'] in ('QUST','SCEN','GLOB','INFO'):
            print(r['type'],r['form'],[(s['tag'],s['strings']) for s in r['fields'] if s['tag'] in ('EDID','FULL','VMAD')])

def extract_scripts():
    with (GAME / 'WICourierRadiant.bsa').open('rb') as f:
        magic,version,offset,flags,folders,files,total_folder_names,total_file_names,file_flags=struct.unpack('<4s8I',f.read(36))
        assert magic == b'BSA\0' and version == 105, (magic,version)
        f.seek(offset)
        directory=[struct.unpack('<QIIQ', f.read(24)) for _ in range(folders)]
        entries=[]
        for _,count,_,_ in directory:
            length=f.read(1)[0]
            folder=f.read(length).rstrip(b'\0').decode()
            for _ in range(count):
                _,size,pos=struct.unpack('<QII',f.read(16))
                entries.append((folder,size,pos))
        names=f.read(total_file_names).split(b'\0')
        for (folder,size,pos),name in zip(entries,names):
            path=(folder+'\\'+name.decode()).replace('\\','/')
            print(path)
            if not path.lower().endswith(('.pex','.psc')):
                continue
            compressed=bool(flags&4) ^ bool(size&0x40000000)
            f.seek(pos)
            data=f.read(size&0x3fffffff)
            if flags&0x100:
                data=data[1+data[0]:]
            if compressed:
                raise RuntimeError('Compressed script requires an LZ4 decoder; no extraction attempted')
            target=ROOT/'research/dependency'/path
            target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(data)
            if path.lower().endswith('.pex'):
                (target.with_suffix('.strings.txt')).write_text('\n'.join(strings(data)),encoding='utf-8')

if __name__=='__main__':
    (ROOT/'research').mkdir(exist_ok=True)
    inspect_plugin()
    extract_scripts()
