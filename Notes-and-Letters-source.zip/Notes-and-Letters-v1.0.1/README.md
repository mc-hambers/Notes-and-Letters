# Notes and Letters — 1.0.1 development build

Version 1.0.1 advances the version with the owner's authorization for the hitch fix. This build includes direct NPC placement, recovery of old queued NPC notes, and the player-courier test command.

An SKSE mod adding small pieces of correspondence to Skyrim. This is an initial development build. Compilation and automated tests have passed; the courier scenes, book rendering, and gameplay triggers still require in-game acceptance testing.

## Requirements and installation

- Skyrim Special Edition or Anniversary Edition, with matching SKSE64 and Address Library for SKSE Plugins.
- Install this archive through your mod manager and enable `NotesAndLetters.esp`. It is ESL-flagged and uses compact local IDs. Keep its filename unchanged.
- Dragonborn supports the Severin Manor letters. Shadowfoot Sanctum must be installed for its house letters; its absence does not block other features.
- No SPID, MCM, or additional dynamic-form framework is used. The DLL supports SE 1.5.97 and the AE runtime versions listed in its runtime guard, including the installed 1.7.104 runtime. Other storefronts/runtimes need separate validation.

No game files or existing companion mods are modified by the build/package tools. Install only when ready to test.

## Authored content

224 original notes have distinct titles: 160 NPC notes, and 64 player letters. The proofreading draft contains their complete text and stable review IDs. `content/notes.json` is the authoritative editable catalog. Run `scripts/build_content.py` and rebuild the DLL after editing it; JSON is build-time source, not a live configuration file. Keep existing note order and IDs stable when updating an existing save.

NPC categories have 20 notes each: romance, condolences, congratulations, gratitude, encouragement, business, welcome, and personal notes/lists. Personal notes and lists never have signatures. Lists contain vanilla item names. Other NPC notes receive varied initials when created; repeated signatures are acceptable. Existing copies keep their chosen text and signature.

Player categories contain 10 spouse letters, 5 jealousy letters, 5 investment letters, 15 friendship letters, 15 hate letters, and 14 house welcomes. The seven houses each have two distinct letters.

## NPC distribution

Living adult NPCs of the ten playable races, their vampire variants, and the elder race are eligible. Children, summons, creatures, dead actors, and the courier are excluded. Active followers remain eligible.

Eligible actor references are discovered without loading their cells. Loaded NPCs and small batches of off-cell references receive an initial roll. Their next refresh is selected once, 3–5 game days later, and checked during loaded or off-cell processing. Loading repeatedly, opening inventory, and reloading a save do not restart a saved timer or grant extra rolls. Missed intervals do not accumulate.

One allowed category is chosen, then a single chance roll is made. Regular NPCs use the earlier 2% baseline, with 1% or 3% occupation modifiers. Repeat combat populations retain half those odds (0.5%, 1%, or 1.5%). These are not eight independent rolls. Thus actual overall odds vary modestly by occupation. At most one pocket note from this system is outstanding per NPC.

At refresh, a note still in that NPC's inventory has a 50% chance of being removed. A retained note prevents another roll. If there is no note afterward, the NPC can receive one new chance roll. Taken notes remain intact. Inventory resets do not bypass the saved refresh timer.

Every successful NPC roll places its note directly in that NPC's inventory. No NPC courier integration, external delivery addon, mod event, or NPC courier script is used. Player letters still use Skyrim's vanilla courier.

On updating, existing NPC pocket notes still owned by the courier are moved as tracked physical copies to their intended recipients. Recovery recognizes copies already in recipient inventories and never creates replacements. Missing/deleted recipients or unavailable physical copies are left pending for recovery rather than duplicated. Delivered recovered copies receive a normal 3–5-day refresh deadline; ordinary existing NPC timers are unchanged. Player courier letters and bundle notes are excluded from recovery.

## Occupation modifiers

Roles are assigned from vanilla factions, with conflicts resolved in this order: bandit, guard, beggar, noble, bard, innkeeper, smith, merchant, farmer, hunter, healer/priest, worker, scholar, ordinary. Unmatched NPCs use ordinary odds. Custom faction/class mappings are not yet configurable.

- Romance: beggars and bandits 1%; nobles and bards 3%; other eligible roles 2%.
- Condolences: beggars and bandits 1%; ordinary townspeople, guards, and farmers 3%; others 2%.
- Congratulations: beggars, bandits, and guards 1%; nobles and bards 3%; others 2%.
- Gratitude: beggars and bandits 1%; innkeepers, healers, and merchants 3%; others 2%.
- Encouragement: beggars and bandits 1%; healers, guards, and workers 3%; others 2%.
- Business: merchants, smiths, and innkeepers 3%; farmers and workers 2%; other roles excluded.
- Welcome: innkeepers and farmers 3%; other settled roles 2%; bandits and hunters excluded.
- Personal notes/lists: merchants, scholars, hunters, and workers 3%; others 2%.

These occupation figures are the full regular-NPC rates. Bandit/Forsworn-role actors retain half rates. Non-unique Imperial/Stormcloak soldiers, warlocks, necromancers, vampires/thralls, Silver Hand and Thalmor members also receive half rates. Named unique members of those latter groups keep full rates; guards without a mapped combat faction retain full rates; generic guards who also belong to the mapped Imperial/Stormcloak combat factions receive the rarer rate. Classification uses verified vanilla combat factions, not government or crime factions, and does not require current hostility to the player. Custom enemies without these factions use regular rates.

## Player letters and initial timing defaults

These conservative defaults fill the probabilities that were not explicitly specified:

- Spouse: 2.5% every 3–5 days. Any married spouse qualifies, using the vanilla marriage quest. Signed with their first name.
- Jealousy: 0.5% every 14–21 days. The player must be married; the sender must be a different NPC at Lover relationship rank. Signed with the sender's initial.
- Friendship: 1% every 5–7 days per encountered named friend or better. Signed with a name or initial.
- Hatred: 0.5% every 7–14 days per encountered named Rival or Foe. Every letter begins with the player's name. It is placed in the sender's inventory for 2–3 days before that exact copy is moved to the vanilla courier's delivery container. Theft, removal, destruction, or the sender's death cancels its delivery. An outstanding draft or player delivery prevents another hate draft from that sender.
- Investment: one 10% roll 2–3 days after a new investment observed by this mod. The vanilla investment statistic and current dialogue merchant identify the event. Older investments are not reconstructed. Merchant name and shop context are captured for the letter; unidentified events are logged and skipped rather than assigned to a guessed merchant.
- House welcomes: one lifetime roll per owned supported home: 42.5% one letter, 5% both unique letters, 52.5% none. A named NPC whose editor location places them in the settlement is selected from loaded residents. If no resident is available, the decision waits. Existing owned houses are included on first activation. Letters are signed with the resident's name or initial.

Spouse checks also run when the spouse is away. Other relationship chances are checked when the sender is encountered. Investment delays and staged hate letters continue independently of the sender's loaded state. Courier arrival still follows vanilla delivery conditions.

## Courier's inventory

The courier has a 50% chance to receive a separate 2–4 note bundle on first activation and every 3–5 days. Only bundle copies still carried by the courier are replaced. Stolen bundle notes remain yours. Pending recipient letters are tracked separately and are not removed by bundle refreshes, so a courier can carry more than four notes when deliveries are waiting.

## Saving and updates

The normal save stores inventories and the SKSE co-save stores note metadata, sender/owner references, signatures, timers, unique-ID changes, house decisions, and delivery state. Load-order FormIDs are remapped. Reloading an older save restores its earlier state. Keep the `.skse` co-save with its matching save file. Missing or corrupt existing records disable distribution rather than silently regenerating items.

Individual books use static light-plugin records and saved extra data; no new dynamic BOOK forms are created. The book-menu hook supplies each saved copy's personalized text. Collected notes therefore require the DLL and their co-save for personalized signatures and addresses. Removing the mod is not an uninstall-supported operation.

## Build and validation

Run `scripts/build_content.py` with Python, then `scripts/build.ps1` with the configured MSVC/vcpkg toolchain. The tool paths can be supplied explicitly. `scripts/package.py` validates the built DLL, records, behavior tests, ZIP integrity, and packaged bytes, then creates an install archive and corresponding source archive.

See `VALIDATION.md` for remaining in-game checks. Logs are written to the Skyrim SKSE log folder as `NotesAndLetters.log`.


## Version 1.0.1 — direct NPC notes

NPC courier integration is retired. Disable/remove the obsolete `NotesAndLetters-CourierEvent.esp` and `Scripts/NL_NPCNoteDelivery.pex` from the old addon. Courier Delivers to NPCs is not required; it can remain installed independently if you want its own unrelated behavior. This release does not edit or stop that mod. Old addon presence cannot route new notes through it, because the native integration and callbacks are gone.

Save schema 2 and stable note identities are retained. Inactive old helper records and serialized migration fields remain solely for existing saves. Keep your matching ESS/SKSE co-save. Do not use resetinventory or delete the co-save to update.

## Player courier test

Load a save, open the console and run:

```text
NLDebug
NLDeliverPlayerNote
```

`NLDeliverNote` is an alias for the new player-delivery command. No crosshair NPC is needed. Each invocation creates one random player letter from the existing 64 texts, waiving relationship, marriage, investment, home, chance and waiting requirements for that one letter only. It places the letter in the vanilla courier container, sends the normal notification, and tries starting the vanilla player courier quest. If newly started, the test brings the courier to the player and evaluates their normal AI. Already-running player deliveries are not stopped, reset or teleported. Close the console so the game can run; if starting the quest is refused, the console reports pending dispatch and normal location/settlement conditions still apply. Debug mode and repeat flags are session-only. Run NLDebug again to disable debug after testing. The physical test letter is an ordinary saved item.

`NLSpawnNote` forces one valid targeted NPC note directly into inventory. `NLRepeatNotes` repeats only direct NPC note distribution. Neither command routes through NPC couriers.

## Validation limits

Build, core migration/persistence checks and archive validation are separate from Skyrim runtime acceptance. Existing-queue recovery, removed-addon updates and actual player-courier arrival/dialogue still need in-game testing. Normal player-letter generation and vanilla notification code are preserved. No in-game success is claimed.

## 1.0.1 performance update

Replaces the once-per-minute global form-table scan/sort with incremental discovery of already registered cell references. Loaded NPCs and load events feed a deduplicated ID queue. A job runs approximately every 33 ms, starts at most four loaded-NPC visits, and stops starting visits after two milliseconds. Off-cell checks process up to four references per 250 ms. Jobs never enqueue same-frame continuations. An individual engine operation cannot be interrupted; slow slices at or above five milliseconds are logged for in-game diagnosis.

Relationship checks are throttled to once per ten real seconds per unique NPC; normal game-day roll timers, probabilities and note limits remain unchanged. Ordinary informational logs no longer force a disk flush for every entry. Debug mode retains immediate diagnostic flushing.

Save compatibility: serialization schema 2, SKSE record IDs, ESP record IDs, note catalog order and all existing note-instance identities are unchanged. Runtime queue/cursor/check caches are not serialized and reset on game entry. Existing queued NPC-note recovery and player courier delivery remain supported. Install over the prior version with Skyrim closed; no new game or clean save is needed.

Validation: native build and behavior tests pass. The installed prior-build Hitch Hunter report measured 18.5�26.5 ms NotesAndLetters tasks. Post-update hitch reduction still requires a fresh in-game run; this is not a measured gameplay performance guarantee.
