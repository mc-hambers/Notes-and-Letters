# Notes and Letters — Complete Proofreading Draft

224 notes: 160 NPC notes and 64 player letters. Draft 1.

Each heading contains a stable review ID and the broad in-game note title. Use the ID when requesting edits. Text beneath the heading is the complete note body.

Braced text is a runtime placeholder, not literal in-game text. NPC signatures are chosen per note instance; repeats are acceptable. Personal notes and lists have no signature. Player letters use the appropriate sender. House welcomes are signed by a resident of the relevant settlement.

NPC notes are self-contained flavor: no quests, rewards, appointments, requests, or specific off-page actions. Personal lists are fragments rather than instructions. Player letters refer only to their stated relationship, investment, or home ownership context.

## Contents

- NPC notes: eight categories, 20 each.
- Player letters: lover 10, jealousy 5, investment 5, friendship 15, hatred 15, house welcomes 14.

## NPC Notes — 160

### Love and Romance Notes (20)

#### NPC-L01 — Note

I love you. There, it's on paper now. Seems easier to say when you aren't looking at me.

— {random_signature}

#### NPC-L02 — Letter

You have a way of making a cold room feel warm. I don't mean the fire.

— {random_signature}

#### NPC-L03 — Personal Note

I tried to make this rhyme. It was awful. I love you will have to do.

— {random_signature}

#### NPC-L04 — Note

There isn't much space on this scrap, but I wanted some of it to belong to you.

— {random_signature}

#### NPC-L05 — Letter

I like the quiet with you. Most people make me feel I ought to fill it.

— {random_signature}

#### NPC-L06 — Personal Note

I was going to write something clever. All I've got is that I'm very fond of you.

— {random_signature}

#### NPC-L07 — Note

You make me smile like a fool. It's getting rather hard to hide.

— {random_signature}

#### NPC-L08 — Letter

I've crossed out three starts to this note. None said it any better. I love you.

— {random_signature}

#### NPC-L09 — Personal Note

Some days I feel old and cross. Somehow there's still a soft bit of me that's yours.

— {random_signature}

#### NPC-L10 — Note

I'd know your laugh in a room full of people. That's a nice thing to know.

— {random_signature}

#### NPC-L11 — Letter

I'm not much for sweet words. But you matter to me, more than I'm any good at saying.

— {random_signature}

#### NPC-L12 — Personal Note

It still catches me off guard, how much I care about you.

— {random_signature}

#### NPC-L13 — Note

I love you, even the bits that would drive anyone else mad. Perhaps those most of all.

— {random_signature}

#### NPC-L14 — Letter

My hand shakes a little writing this. Nothing wrong with it. I'm just thinking of you.

— {random_signature}

#### NPC-L15 — Personal Note

You don't have to be cheerful for me. I like you on the grey days too.

— {random_signature}

#### NPC-L16 — Note

A whole page wouldn't be enough. This little scrap will have to carry the rest.

— {random_signature}

#### NPC-L17 — Letter

I keep trying to make this sound less foolish. It seems love makes fools of us.

— {random_signature}

#### NPC-L18 — Personal Note

You're the first person I want beside me when the world gets too loud.

— {random_signature}

#### NPC-L19 — Note

I love you. I'm leaving that plain, before I spoil it with too many words.

— {random_signature}

#### NPC-L20 — Letter

I dont know a grand way to say it. I'd choose you again.

— {random_signature}

### Sympathy and Condolence Notes (20)

#### NPC-S01 — Personal Note

I'm sorry. Everything else I put after that felt too small, so I'll leave it there.

— {random_signature}

#### NPC-S02 — Note

I wish there were words that made a loss lighter. I haven't found them.

— {random_signature}

#### NPC-S03 — Letter

You needn't find an answer to this. I just wanted you to know I care.

— {random_signature}

#### NPC-S04 — Personal Note

A quiet room can feel cruel after someone is gone. I'm so sorry.

— {random_signature}

#### NPC-S05 — Note

I hope the good memories bring some warmth, even if they hurt a little too.

— {random_signature}

#### NPC-S06 — Letter

There isn't a right way to grieve. Don't let anyone tell you there is.

— {random_signature}

#### NPC-S07 — Personal Note

I'm sorry for your loss. That sounds thin on paper. I mean it with all my heart.

— {random_signature}

#### NPC-S08 — Note

A life leaves more behind than an empty chair. I hope that brings you some comfort.

— {random_signature}

#### NPC-S09 — Letter

Some days are only for getting through. That is enough.

— {random_signature}

#### NPC-S10 — Personal Note

You have my sympathy. I wish I had something better to offer than ink.

— {random_signature}

#### NPC-S11 — Note

The world ought to stop for a loss like yours. It feels wrong that it doesn't.

— {random_signature}

#### NPC-S12 — Letter

You needn't be brave every moment. Being tired doesn't mean you loved any less.

— {random_signature}

#### NPC-S13 — Personal Note

I hope there are gentle moments among the hard ones.

— {random_signature}

#### NPC-S14 — Note

I'm thinking of you with a heavy heart. No fine words today.

— {random_signature}

#### NPC-S15 — Letter

You can miss someone and smile at a memory in the same breath.

— {random_signature}

#### NPC-S16 — Personal Note

There are things a person never gets used to. I hope this grows easier to carry.

— {random_signature}

#### NPC-S17 — Note

I'm so sorry. Please don't feel you owe anyone a cheerful face.

— {random_signature}

#### NPC-S18 — Letter

Grief takes up so much room. I hope kindness finds a little room beside it.

— {random_signature}

#### NPC-S19 — Personal Note

I wish this were a note about anything else. You have my deepest sympathy.

— {random_signature}

#### NPC-S20 — Note

It hardly seems fair. I havn't anything wise to say, only that I'm sorry.

— {random_signature}

### Congratulations and Milestone Notes (20)

#### NPC-C01 — Letter

Happy birthday. Another year older, and still more sense than most of us.

— {random_signature}

#### NPC-C02 — Personal Note

Well done. I hope you're letting yourself feel proud of it.

— {random_signature}

#### NPC-C03 — Note

A new baby! Such a small person to take up so much of a heart.

— {random_signature}

#### NPC-C04 — Letter

Congratulations to you both. May your marriage have plenty of laughter in it.

— {random_signature}

#### NPC-C05 — Personal Note

Happy birthday. May your knees be kind and your cup be full.

— {random_signature}

#### NPC-C06 — Note

You deserve a good day. I hope this is the start of several.

— {random_signature}

#### NPC-C07 — Letter

That's something worth being proud of. Don't brush it off.

— {random_signature}

#### NPC-C08 — Personal Note

A new home of your own. I hope it feels like yours before long.

— {random_signature}

#### NPC-C09 — Note

Congratulations. That little word looks too small for such good news.

— {random_signature}

#### NPC-C10 — Letter

Happy birthday, you old goat. That's meant fondly.

— {random_signature}

#### NPC-C11 — Personal Note

A child brings so much hope into a room. Warm wishes to your growing family.

— {random_signature}

#### NPC-C12 — Note

To the newly married pair. May you be kind to each other when you're tired.

— {random_signature}

#### NPC-C13 — Letter

Good news for once! It feels good just to put those words on paper.

— {random_signature}

#### NPC-C14 — Personal Note

Another year. I hope there's more joy than worry in this one.

— {random_signature}

#### NPC-C15 — Note

Well done. You needn't be shy about enjoying it.

— {random_signature}

#### NPC-C16 — Letter

A fresh start is a fine thing. I hope yours is a happy one.

— {random_signature}

#### NPC-C17 — Personal Note

Congratulations on the little one. May there be strong lungs and a gentle temper.

— {random_signature}

#### NPC-C18 — Note

Happy birthday. You're still younger than you will be next year.

— {random_signature}

#### NPC-C19 — Letter

I'm glad there's something to smile about. You deserve it.

— {random_signature}

#### NPC-C20 — Personal Note

Congratualtions! I wrote that too fast. You know what I mean.

— {random_signature}

### Thank-You Notes (20)

#### NPC-T01 — Note

Thank you. I know it's only two words, but they're honest ones.

— {random_signature}

#### NPC-T02 — Letter

It's good to have someone like you in the world.

— {random_signature}

#### NPC-T03 — Personal Note

You're kinder than you need to be. I hope you know that.

— {random_signature}

#### NPC-T04 — Note

I don't say it well out loud. I'm glad you're my friend.

— {random_signature}

#### NPC-T05 — Letter

A small thank you, on a rather grubby bit of paper. It still counts.

— {random_signature}

#### NPC-T06 — Personal Note

Some people make everything harder. You aren't one of them.

— {random_signature}

#### NPC-T07 — Note

I hope you know how much you're worth to the people who care about you.

— {random_signature}

#### NPC-T08 — Letter

You make things feel a little less lonely. Thank you for that.

— {random_signature}

#### NPC-T09 — Personal Note

This is just a friend's thanks. No great reason needed.

— {random_signature}

#### NPC-T10 — Note

I'm not good at warm words. Please take these as warmly as I mean them.

— {random_signature}

#### NPC-T11 — Letter

You've got a good heart. Don't let anyone make you feel foolish for it.

— {random_signature}

#### NPC-T12 — Personal Note

I like knowing there are decent people about. You're one of mine.

— {random_signature}

#### NPC-T13 — Note

Thank you. There ought to be a bigger word for it sometimes.

— {random_signature}

#### NPC-T14 — Letter

Good friends are scarce. I'm glad I can count you among them.

— {random_signature}

#### NPC-T15 — Personal Note

I know I sound cross half the time. That doesn't mean I'm not grateful.

— {random_signature}

#### NPC-T16 — Note

You're a comfort to know. I thought you ought to hear it.

— {random_signature}

#### NPC-T17 — Letter

There isn't any grand speech here. Just honest thanks.

— {random_signature}

#### NPC-T18 — Personal Note

A kind heart is worth more than a heavy purse. Yours, anyway.

— {random_signature}

#### NPC-T19 — Note

I'm glad of you. That's the whole note.

— {random_signature}

#### NPC-T20 — Letter

Thank you for being a freind. Apparently spelling is harder than gratitude.

— {random_signature}

### Get-Well and Encouragement Notes (20)

#### NPC-G01 — Personal Note

I hope you're feeling a little better. A little counts.

— {random_signature}

#### NPC-G02 — Note

Rest isn't something you have to earn. You need it, same as anyone.

— {random_signature}

#### NPC-G03 — Letter

A bad day isn't a whole life. I hope tomorrow feels kinder.

— {random_signature}

#### NPC-G04 — Personal Note

You needn't put on a brave face with me.

— {random_signature}

#### NPC-G05 — Note

Healing is slow, and waiting is rotten. I'm hoping for easier days for you.

— {random_signature}

#### NPC-G06 — Letter

I wish you a quiet head, a warm bed, and a decent night's sleep.

— {random_signature}

#### NPC-G07 — Personal Note

You're allowed to be tired. Even the strongest back needs a rest.

— {random_signature}

#### NPC-G08 — Note

I hope the ache eases soon. It's miserable feeling unlike yourself.

— {random_signature}

#### NPC-G09 — Letter

One small good thing can be enough for a day.

— {random_signature}

#### NPC-G10 — Personal Note

There's no shame in needing help. I mean that.

— {random_signature}

#### NPC-G11 — Note

I hope your strength comes back a little at a time.

— {random_signature}

#### NPC-G12 — Letter

You don't have to mend all at once. Slow is still mending.

— {random_signature}

#### NPC-G13 — Personal Note

A hard winter doesn't last forever, though it can feel that way.

— {random_signature}

#### NPC-G14 — Note

Be as kind to yourself as you are to everyone else.

— {random_signature}

#### NPC-G15 — Letter

I hope something makes you laugh today. Even if it hurts a bit.

— {random_signature}

#### NPC-G16 — Personal Note

I'm sorry things feel so heavy. You aren't weak for finding them heavy.

— {random_signature}

#### NPC-G17 — Note

Some days keeping going is plenty. Don't ask more of yourself than that.

— {random_signature}

#### NPC-G18 — Letter

I hope there's less pain and more peace in the days ahead.

— {random_signature}

#### NPC-G19 — Personal Note

You matter, even when you don't feel much use to anyone.

— {random_signature}

#### NPC-G20 — Note

I hope you feel better tomorow. And if not tomorrow, soon.

— {random_signature}

### Business and Client Notes (20)

#### NPC-B01 — Letter

Please count the crates before signing. It saves hard words later.

— {random_signature}

#### NPC-B02 — Personal Note

A fair price and sound goods. That's all I ask.

— {random_signature}

#### NPC-B03 — Note

The coin needs counting twice. Trust is good. Sums are better.

— {random_signature}

#### NPC-B04 — Letter

I'd rather hear a plain no than a yes that means nothing.

— {random_signature}

#### NPC-B05 — Personal Note

Good iron is worth paying for. Rust with a fine story isn't.

— {random_signature}

#### NPC-B06 — Note

A small shop can't afford large mistakes.

— {random_signature}

#### NPC-B07 — Letter

If the price has changed, put it in ink. My memory isn't a ledger.

— {random_signature}

#### NPC-B08 — Personal Note

I'd sooner keep a good customer than squeeze the last septim out of one.

— {random_signature}

#### NPC-B09 — Note

Please write the full amount. A smudge isn't a number.

— {random_signature}

#### NPC-B10 — Letter

There's room for both of us to earn a living. No need to make enemies of it.

— {random_signature}

#### NPC-B11 — Personal Note

A promise doesn't weigh much against an empty purse.

— {random_signature}

#### NPC-B12 — Note

I don't mind a hard bargain. I mind finding a different one on the bill.

— {random_signature}

#### NPC-B13 — Letter

Dry goods need dry crates. That ought to go without saying.

— {random_signature}

#### NPC-B14 — Personal Note

Good work deserves good pay. Cheap work usually costs twice.

— {random_signature}

#### NPC-B15 — Note

A tidy account makes for a peaceful night.

— {random_signature}

#### NPC-B16 — Letter

I value steady trade more than a quick handful of coin.

— {random_signature}

#### NPC-B17 — Personal Note

Please leave room for the tally marks. These margins are too narrow.

— {random_signature}

#### NPC-B18 — Note

A price in writing is kinder to everyone.

— {random_signature}

#### NPC-B19 — Letter

I'm happy with fair terms. I don't need fancy ones.

— {random_signature}

#### NPC-B20 — Personal Note

Please check the reciept. The second figure is a seven, however it looks.

— {random_signature}

### Welcome Notes (20)

#### NPC-W01 — Note

Welcome. I hope this place starts to feel like home soon.

— {random_signature}

#### NPC-W02 — Letter

New faces make a town less dull. I'm glad yours is here.

— {random_signature}

#### NPC-W03 — Personal Note

A warm hearth and quiet nights to you.

— {random_signature}

#### NPC-W04 — Note

It takes time to know a place. I hope it treats you kindly while you do.

— {random_signature}

#### NPC-W05 — Letter

Welcome, neighbour. That's a good word to have for someone.

— {random_signature}

#### NPC-W06 — Personal Note

May your roof stay sound and your door find friendly faces.

— {random_signature}

#### NPC-W07 — Note

I hope you find a corner of this place that feels yours.

— {random_signature}

#### NPC-W08 — Letter

There's always room for one more decent soul.

— {random_signature}

#### NPC-W09 — Personal Note

Welcome. No grand speech, just good wishes.

— {random_signature}

#### NPC-W10 — Note

Unfamiliar streets don't stay unfamiliar forever.

— {random_signature}

#### NPC-W11 — Letter

A new start can feel rather lonely. I hope yours doesn't for long.

— {random_signature}

#### NPC-W12 — Personal Note

May the cold stay outside and the warmth stay in.

— {random_signature}

#### NPC-W13 — Note

Welcome to this little patch of Skyrim.

— {random_signature}

#### NPC-W14 — Letter

I hope the place suits you, draughts and all.

— {random_signature}

#### NPC-W15 — Personal Note

A town is only its people. I'm glad to have another neighbour.

— {random_signature}

#### NPC-W16 — Note

May your days here be ordinary in the nicest way.

— {random_signature}

#### NPC-W17 — Letter

I hope you can put your feet up and feel at home.

— {random_signature}

#### NPC-W18 — Personal Note

Here's a small welcome on a small piece of paper.

— {random_signature}

#### NPC-W19 — Note

New walls, new faces. I hope there's good in both.

— {random_signature}

#### NPC-W20 — Letter

Welcome, neigbour. My spelling's worse than my good wishes.

— {random_signature}

### Personal Lists and Notes (20)

#### NPC-P01 — Shopping List

Salt Pile  
Bread  
Red Apple  
Honey

#### NPC-P02 — Shopping List

Lockpick  
Torch  
Leather Strips

#### NPC-P03 — Letter

Patience, honesty, and a sense of humor. Worth more than fine boots.

#### NPC-P04 — Shopping List

Lavender  
Blue Mountain Flower  
Thistle Branch  
Juniper Berries

#### NPC-P05 — Note

A warm room, a sound roof, and enough bread. A modest measure of comfort.

#### NPC-P06 — Letter

Rain has a different voice on every roof.

#### NPC-P07 — Personal Note

Morning light. Midday noise. Evening quiet.

#### NPC-P08 — Shopping List

Linen Wrap  
Leather  
Leather Strips

#### NPC-P09 — Letter

Enough is a kinder word than more.

#### NPC-P10 — Shopping List

Bread  
Goat Cheese Wedge  
Elves Ear  
Nord Mead

#### NPC-P11 — Shopping List

Iron Ingot  
Steel Ingot  
Corundum Ingot  
Leather Strips

#### NPC-P12 — Letter

Is silence still silence when the kettle is singing?

#### NPC-P13 — Shopping List

Sweet Roll  
Honey Nut Treat  
Boiled Creme Treat  
Alto Wine

#### NPC-P14 — Note

The hills are gray, the sky is wide;  
The pines stand dark on either side.

#### NPC-P15 — Shopping List

Frost Mirriam  
Garlic  
Juniper Berries  
Snowberries

#### NPC-P16 — Shopping List

Torch  
Lockpick  
Potion of Minor Healing

#### NPC-P17 — Note

A little good sense is less showy than a fine hat and rather more useful.

#### NPC-P18 — Letter

Snow makes even a familiar road look like a new thought.

#### NPC-P19 — Shopping List

Wooden Plate  
Wooden Bowl  
Tankard

#### NPC-P20 — Note

A kettle, a hearth, and rain against a shutter. A fine little orchestra.

## Player Letters — 64

### Lover Notes (10)

#### PLAYER-LOVE01 — Letter

I love you. You know that, but I like putting it where you can read it too.

— {spouse_first_name}

#### PLAYER-LOVE02 — Letter

Being married to you still makes me smile. Rather silly of me, perhaps. I don't mind.

— {spouse_first_name}

#### PLAYER-LOVE03 — Letter

You get the best of my heart, even when the rest of me is tired and cross.

— {spouse_first_name}

#### PLAYER-LOVE04 — Letter

No poem today. Just your spouse being hopelessly fond of you.

— {spouse_first_name}

#### PLAYER-LOVE05 — Letter

Sometimes I think how odd it is that out of everyone, we found each other.

— {spouse_first_name}

#### PLAYER-LOVE06 — Letter

I like the life that has your name in it.

— {spouse_first_name}

#### PLAYER-LOVE07 — Letter

You're still my favourite person. Even when you're being a nuisance.

— {spouse_first_name}

#### PLAYER-LOVE08 — Letter

It's good, being us. I hope you feel that too.

— {spouse_first_name}

#### PLAYER-LOVE09 — Letter

I love you on the dull days as much as the bright ones.

— {spouse_first_name}

#### PLAYER-LOVE10 — Letter

I dont have anything clever to write. Just that I'm glad I married you.

— {spouse_first_name}

### Jealousy Notes (5)

#### PLAYER-JEAL01 — Letter

You're married. I know. Knowing doesn't seem to help much.

— {other_lover_initial}

#### PLAYER-JEAL02 — Letter

I wish I could be happy for you without that little twist in my chest.

— {other_lover_initial}

#### PLAYER-JEAL03 — Letter

Someone else gets to call you theirs. I find I mind that more than I ought to.

— {other_lover_initial}

#### PLAYER-JEAL04 — Letter

This is a foolish note. I'm jealous, and there's no nice way to write it.

— {other_lover_initial}

#### PLAYER-JEAL05 — Letter

I keep telling myself to have some sense. So far it isnt working.

— {other_lover_initial}

### Investment Notes (5)

#### PLAYER-INV01 — Letter

Thank you for putting coin into {shop}. A small shop means an awful lot to the person keeping it.

— {merchant_name}, {shop}

#### PLAYER-INV02 — Letter

Your coin in {shop} means more breathing room. I'm grateful for that.

— {merchant_name}, {shop}

#### PLAYER-INV03 — Letter

It's a good feeling, knowing someone thinks {shop} is worth backing. Thank you.

— {merchant_name}, {shop}

#### PLAYER-INV04 — Letter

Thank you for the investment in {shop}. I'd put that more grandly if I knew how.

— {merchant_name}, {shop}

#### PLAYER-INV05 — Letter

There's a lot of worry behind a shop counter. Your help with {shop} means a little less of it.

— {merchant_name}, {shop}

### Thank-You Notes (15)

#### PLAYER-FRIEND01 — Letter

It's good to know you. I don't say that often enough.

— {friend_name_or_initial}

#### PLAYER-FRIEND02 — Letter

I'm glad we're friends. There doesn't have to be more to this note than that.

— {friend_name_or_initial}

#### PLAYER-FRIEND03 — Letter

The world feels a little less sharp with a friend like you in it.

— {friend_name_or_initial}

#### PLAYER-FRIEND04 — Letter

I hope you know I think well of you.

— {friend_name_or_initial}

#### PLAYER-FRIEND05 — Letter

Some people are easier to be yourself around. You're one of them.

— {friend_name_or_initial}

#### PLAYER-FRIEND06 — Letter

A small note to a good friend. That's you, in case there's any doubt.

— {friend_name_or_initial}

#### PLAYER-FRIEND07 — Letter

I'm glad of your friendship. My handwriting seems a poor way to show it.

— {friend_name_or_initial}

#### PLAYER-FRIEND08 — Letter

It's nice knowing someone I can think of fondly without a long list of buts.

— {friend_name_or_initial}

#### PLAYER-FRIEND09 — Letter

I value you. I know that sounds plain. It's meant warmly.

— {friend_name_or_initial}

#### PLAYER-FRIEND10 — Letter

I hope life is being decent to you. You deserve decent.

— {friend_name_or_initial}

#### PLAYER-FRIEND11 — Letter

This is only a scrap of paper, but there's real fondness in it.

— {friend_name_or_initial}

#### PLAYER-FRIEND12 — Letter

You're good company, even as a thought.

— {friend_name_or_initial}

#### PLAYER-FRIEND13 — Letter

There aren't so many good friends that I can afford to take one for granted.

— {friend_name_or_initial}

#### PLAYER-FRIEND14 — Letter

You have a place in my heart. A friend's place, before you get any ideas.

— {friend_name_or_initial}

#### PLAYER-FRIEND15 — Letter

I'm glad you're my freind. Don't judge the spelling.

— {friend_name_or_initial}

### I Hate You Notes (15)

#### PLAYER-HATE01 — Letter

{player_name},  
  
I can't stand you. There. No need to dress it up.

— {rival_name_or_initial}

#### PLAYER-HATE02 — Letter

{player_name},  
  
You think rather a lot of yourself. I think rather less.

— {rival_name_or_initial}

#### PLAYER-HATE03 — Letter

{player_name},  
  
I have nothing kind to say about you, so this will be short.

— {rival_name_or_initial}

#### PLAYER-HATE04 — Letter

{player_name},  
  
Even your name leaves a bad taste in my mouth.

— {rival_name_or_initial}

#### PLAYER-HATE05 — Letter

{player_name},  
  
I dislike you more than is worth the price of this ink.

— {rival_name_or_initial}

#### PLAYER-HATE06 — Letter

{player_name},  
  
There's no fondness here. I wanted that clear.

— {rival_name_or_initial}

#### PLAYER-HATE07 — Letter

{player_name},  
  
I hope this is plain enough. I want nothing to do with you.

— {rival_name_or_initial}

#### PLAYER-HATE08 — Letter

{player_name},  
  
Some people improve a room by leaving it. You come to mind.

— {rival_name_or_initial}

#### PLAYER-HATE09 — Letter

{player_name},  
  
My opinion of you hasn't softened. In case you wondered.

— {rival_name_or_initial}

#### PLAYER-HATE10 — Letter

{player_name},  
  
You wear on the nerves, even at a distance.

— {rival_name_or_initial}

#### PLAYER-HATE11 — Letter

{player_name},  
  
I don't care for you. That's as polite as I can manage.

— {rival_name_or_initial}

#### PLAYER-HATE12 — Letter

{player_name},  
  
I tried to think of something good to say. Empty page.

— {rival_name_or_initial}

#### PLAYER-HATE13 — Letter

{player_name},  
  
If you think we're friends, allow me to put that right.

— {rival_name_or_initial}

#### PLAYER-HATE14 — Letter

{player_name},  
  
I have a low opinion of you and no wish to raise it.

— {rival_name_or_initial}

#### PLAYER-HATE15 — Letter

{player_name},  
  
I dont like you. You aren't worth another sheet of paper.

— {rival_name_or_initial}

### House Welcome: Breezehome (2)

#### PLAYER-BREEZE01 — Letter

Welcome to Breezehome. Small rooms, but there's comfort in that. I hope Whiterun feels like home to you.

— {local_resident_name_or_initial}

#### PLAYER-BREEZE02 — Letter

Breezehome is a good name for a place in Whiterun. May the breeze stay outside when the shutters are shut. Welcome, neighbour.

— {local_resident_name_or_initial}

### House Welcome: Honeyside (2)

#### PLAYER-HONEY01 — Letter

Welcome to Honeyside. I hope your little corner of Riften gives you some peace.

— {local_resident_name_or_initial}

#### PLAYER-HONEY02 — Letter

A home by the water sounds a fine thing. Warm wishes for Honeyside, and welcome to Riften.

— {local_resident_name_or_initial}

### House Welcome: Vlindrel Hall (2)

#### PLAYER-VLINDREL01 — Letter

Welcome to Vlindrel Hall. Markarth has a hard face, but I hope your home feels warm inside.

— {local_resident_name_or_initial}

#### PLAYER-VLINDREL02 — Letter

Those old stone walls at Vlindrel Hall have stood a long while. I hope there's a good, quiet life within them for you.

— {local_resident_name_or_initial}

### House Welcome: Hjerim (2)

#### PLAYER-HJERIM01 — Letter

Welcome to Hjerim. Windhelm can be a cold place. I hope your hearth makes up for it.

— {local_resident_name_or_initial}

#### PLAYER-HJERIM02 — Letter

A warm welcome for your home in Hjerim. It feels a small thing to send against all that Windhelm cold.

— {local_resident_name_or_initial}

### House Welcome: Proudspire Manor (2)

#### PLAYER-PROUD01 — Letter

Proudspire Manor is quite a name to put on a letter. I hope the place is as comfortable as it is grand. Welcome to Solitude.

— {local_resident_name_or_initial}

#### PLAYER-PROUD02 — Letter

Welcome to Proudspire. I hope even a house that fine has a good chair close to the fire.

— {local_resident_name_or_initial}

### House Welcome: Severin Manor (2)

#### PLAYER-SEVERIN01 — Letter

Welcome to Severin Manor. Raven Rock takes some getting used to. I hope the house helps you feel settled.

— {local_resident_name_or_initial}

#### PLAYER-SEVERIN02 — Letter

Good wishes for your home at Severin Manor. There's warmth to be found in Raven Rock, ash and all.

— {local_resident_name_or_initial}

### House Welcome: Shadowfoot Sanctum (2)

#### PLAYER-SHADOW01 — Letter

Welcome to Shadowfoot Sanctum. A quiet corner beneath Riften sounds rather nice, all things considered.

— {local_resident_name_or_initial}

#### PLAYER-SHADOW02 — Letter

Warm wishes for Shadowfoot Sanctum. A place under the streets deserves a cheerful hearth as much as any other.

— {local_resident_name_or_initial}
