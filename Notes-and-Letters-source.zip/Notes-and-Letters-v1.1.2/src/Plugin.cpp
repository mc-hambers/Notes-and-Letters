#include "Core.h"
#include "ActorWorkQueue.h"
#include "Catalog.h"
#include "DebugConfig.h"
#include "RuntimeExtraData.h"
#include "FormResolution.h"
#include <fstream>
#include <filesystem>
#include <new>
#include <spdlog/sinks/basic_file_sink.h>
#include <atomic>
#include <chrono>
#include <mutex>
#include <thread>
#include <set>
namespace logger=SKSE::log;
namespace {
using namespace NL;
using namespace std::chrono_literals;
constexpr unsigned saveID=0x4E4C3031,recordID=0x4E4F5445;
constexpr std::array<unsigned,22> humanRaces{0x13740,0x13741,0x13742,0x13743,0x13744,0x13745,0x13746,0x13747,0x13748,0x13749,0x8883A,0x8883C,0x8883D,0x88840,0x88844,0x88845,0x88794,0xA82B9,0x88846,0x88884,0x67CD8,0xA82BA};
std::string replace(std::string s,std::string_view from,std::string_view to) {std::size_t p=0;while ((p=s.find(from,p))!=std::string::npos) {s.replace(p,from.size(),to);p+=to.size();}return s;}
std::string escaped(std::string s) {s=replace(s,"&","&amp;");s=replace(s,"<","&lt;");s=replace(s,">","&gt;");return replace(s,"\n","<br>");}
std::string first(std::string s) {auto p=s.find(' ');return s.substr(0,p);}
std::string initial(std::string s) {if (s.empty()) return "?";auto c=static_cast<unsigned char>(s[0]);unsigned count=c<0x80 ? 1 : c<0xE0 ? 2 : c<0xF0 ? 3 : 4;return s.substr(0,count)+".";}
struct Movement {unsigned book,uid,oldOwner,newOwner;};
struct UniqueChange {unsigned book,oldBase,newBase,oldUID,newUID;};
class Manager final : public RE::BSTEventSink<RE::TESObjectLoadedEvent>,public RE::BSTEventSink<RE::TESContainerChangedEvent>,public RE::BSTEventSink<RE::TESTrackedStatsEvent>,public RE::BSTEventSink<RE::TESUniqueIDChangeEvent>,public RE::BSTEventSink<SKSE::CrosshairRefEvent> {
public:
    static Manager& get() {static Manager m;return m;}
    Config config;RE::ObjectRefHandle debugTarget;bool repeatNotes=false;
    Data data;std::atomic_bool active{false};std::atomic_uint64_t session{0};bool valid=true;
    std::array<RE::TESObjectBOOK*,textCount*modelCount> books{};
    std::vector<unsigned> remoteActors, discoveryCells;std::set<unsigned> knownActors;
    std::size_t remoteCursor=0,cellCursor=0;ActorWorkQueue actorWork;std::set<unsigned> highActors;
    std::map<unsigned,std::chrono::steady_clock::time_point> relationshipChecks;
    std::chrono::steady_clock::time_point nextMaintenance{},nextRemote{},nextDiscovery{},nextRelationships{};
    void rememberActor(unsigned id) {if (id && knownActors.size()<100000 && knownActors.insert(id).second) remoteActors.push_back(id);}
    void resetWork() {remoteActors.clear();knownActors.clear();highActors.clear();actorWork.clear();relationshipChecks.clear();remoteCursor=0;cellCursor=0;nextMaintenance={};nextRemote={};nextDiscovery={};nextRelationships={};}
    RE::TESQuest *playerQuest=nullptr,*marriage=nullptr;
    RE::TESObjectREFR *courier=nullptr,*container=nullptr;RE::TESGlobal* itemCount=nullptr;
    RE::BGSKeyword* habitation=nullptr;
    std::array<RE::TESObjectCELL*,7> homes{};
    void initialize() {
        std::ifstream ini(std::filesystem::path(REL::Module::get().filePath().data()).parent_path()/"Data/SKSE/Plugins/NotesAndLetters.ini");
        if (ini) config=readConfig(ini);setDebug(config.debug);
        auto* h=RE::TESDataHandler::GetSingleton();
        for (auto* cell:h->GetFormArray<RE::TESObjectCELL>()) if (cell) discoveryCells.push_back(cell->GetFormID());
        unsigned repairedArt=0;
        for (unsigned i=0;i<books.size();++i) {
            books[i]=h->LookupForm<RE::TESObjectBOOK>(0x800+i,"NotesAndLetters.esp");
            auto* art=h->LookupForm<RE::TESObjectSTAT>(noteArtIDs[i/textCount],"Skyrim.esm");
            if (books[i] && !books[i]->inventoryModel && art) {books[i]->inventoryModel=art;++repairedArt;}
        }
        logger::info("Paper-note model variants={}; repaired {} missing art links",modelCount,repairedArt);
        playerQuest=h->LookupForm<RE::TESQuest>(0x39F82,"Skyrim.esm");marriage=h->LookupForm<RE::TESQuest>(0x21382,"Skyrim.esm");
        courier=resolveReference<RE::TESObjectREFR>(h,0x39FB7);container=resolveReference<RE::TESObjectREFR>(h,0x39FB9);itemCount=h->LookupForm<RE::TESGlobal>(0x39FBB,"Skyrim.esm");
        habitation=h->LookupForm<RE::BGSKeyword>(0x39793,"Skyrim.esm");
        constexpr std::array<unsigned,5> ids{0x165A8,0x16BDD,0x16DFA,0x16778,0x16A06};
        for (unsigned i=0;i<5;++i) homes[i]=h->LookupForm<RE::TESObjectCELL>(ids[i],"Skyrim.esm");
        homes[5]=h->LookupForm<RE::TESObjectCELL>(0x17EBE,"Dragonborn.esm");
        // Optional Creation Club home: locate its actual CELL rather than guessing a local FormID.
        for (auto* cell:h->GetFormArray<RE::TESObjectCELL>()) if (cell && std::string_view(cell->GetName())=="Shadowfoot Sanctum") homes[6]=cell;
        const auto resolved=std::count_if(books.begin(),books.end(),[](auto* b) {return b!=nullptr;});
        formsReady=std::size_t(resolved)==books.size() && playerQuest && courier && container && itemCount && habitation;
        logger::info("Required forms: books={}/896, player quest={}, courier ACHR={}, container={}, item count={}, habitation={}",resolved,playerQuest!=nullptr,courier!=nullptr,container!=nullptr,itemCount!=nullptr,habitation!=nullptr);
        if (!formsReady) logger::error("Missing required records; enable NotesAndLetters.esp and check the required-form diagnostic above");
        if (auto* crosshair=SKSE::GetCrosshairRefEventSource()) crosshair->AddEventSink(this);
        auto* src=RE::ScriptEventSourceHolder::GetSingleton();src->AddEventSink<RE::TESObjectLoadedEvent>(this);src->AddEventSink<RE::TESContainerChangedEvent>(this);src->AddEventSink<RE::TESTrackedStatsEvent>(this);src->AddEventSink<RE::TESUniqueIDChangeEvent>(this);
        logger::info("Catalog resolved={}; NPC notes use direct inventories; optional Shadowfoot cell={}",formsReady,homes[6]!=nullptr);
        worker=std::jthread([this](std::stop_token stop) {while (!stop.stop_requested()) {std::this_thread::sleep_for(33ms);if (active && !stop.stop_requested()) queueScan();}});
    }
    void reset() {resetWork();repeatNotes=false;debugTarget={};active=false;++session;valid=true;data={};data.random.value=std::chrono::high_resolution_clock::now().time_since_epoch().count();queued=false;{std::scoped_lock lock(inboxMutex);movements.clear();uniqueChanges.clear();investments.clear();}}
    std::string inactiveReason() const {
        if (!formsReady) return "Notes and Letters: required game/plugin records are unresolved. Enable NotesAndLetters.esp; see the Required forms line in NotesAndLetters.log.";
        if (!valid) return "Notes and Letters: saved note metadata is unreadable. Load an earlier matching ESS/SKSE save; existing notes have not been regenerated.";
        return "Notes and Letters: no active loaded game. Load a save and wait for startup.";
    }
    void enter() {
        if (!formsReady || !valid) {active=false;report(inactiveReason());return;}
        // Save compatibility only: stop the retired helper without operating its AI or aliases.
        if (auto* legacy=RE::TESDataHandler::GetSingleton()->LookupForm<RE::TESQuest>(0xC00,"NotesAndLetters.esp");legacy && legacy->IsRunning()) {legacy->Stop();logger::info("Stopped retired courier helper quest");}
        data.helperDelivery=false;data.courierKey=0;data.courierTarget=0;data.sceneSeen=false;
        resetWork();for (const auto& [id,state]:data.actors) rememberActor(id);queued=false;notificationOutstanding=false;active=true;discoverActorsAtLoad();queueScan();
        logger::info("Notes enabled: {} NPC states, {} note instances; NPC placement is direct",data.actors.size(),data.notes.size());
    }
    template<class F> void queue(F f) {auto epoch=session.load();SKSE::GetTaskInterface()->AddTask([this,epoch,f=std::move(f)] {if (active && session==epoch) f();});}
    void queueScan() {if (queued.exchange(true)) return;queue([this] {queued=false;scan();});}
    double now() const {return RE::Calendar::GetSingleton()->GetDaysPassed();}
    bool eligible(RE::Actor* a) const {
        if (!a || a->IsPlayerRef() || a==courier || !a->GetActorBase() || !a->GetRace() || a->IsChild() || a->IsDead() || a->IsDeleted() || a->IsDisabled() || a->IsSummoned() || a->GetCommandingActor()) return false;
        const auto race=a->GetRace()->GetFormID();return std::find(humanRaces.begin(),humanRaces.end(),race)!=humanRaces.end();
    }
    bool faction(RE::Actor* a,unsigned id) const {auto* f=RE::TESForm::LookupByID<RE::TESFaction>(id);return f && a->IsInFaction(f);}
    Role role(RE::Actor* a) const {
        if (faction(a,0x1BCC0) || faction(a,0x43599)) return Bandit;
        if (a->IsGuard()) return Guard;
        if (faction(a,0x60028)) return Beggar;
        if (faction(a,0x50920) || faction(a,0x50922) || faction(a,0x102D60)) return Noble;
        if (faction(a,0x53514)) return Bard;
        if (faction(a,0x5091B)) return Innkeeper;
        if (faction(a,0x5091D)) return Smith;
        if (faction(a,0x51596)) return Merchant;
        if (faction(a,0x51591)) return Farmer;
        if (faction(a,0x4E509) || faction(a,0xAC9C2)) return Hunter;
        if (faction(a,0x5091C) || faction(a,0x5159A)) return Healer;
        if (faction(a,0x51597) || faction(a,0x51595)) return Worker;
        if (faction(a,0x1F259)) return Scholar;
        return Ordinary;
    }
    RE::BGSLocation* settlement(RE::BGSLocation* loc) const {
        std::set<RE::BGSLocation*> seen;RE::BGSLocation* result=nullptr;
        while (loc && seen.size()<64 && seen.insert(loc).second) {if (habitation && loc->HasKeyword(habitation)) result=loc;loc=loc->parentLoc;}return result;
    }
    bool rarerPocketNPC(RE::Actor* a) const {
        // Skyrim.esm faction EDIDs verified from the installed master. Do not use crime/government factions.
        constexpr std::array<unsigned,10> combatFactions{0x2BF9A,0x2BF9B,0x1C9FC,0x1C9FD,0x26724,0x34B74,0x27242,0x2EB13,0xAA0A4,0x39F26};
        const bool combat=std::any_of(combatFactions.begin(),combatFactions.end(),[&](unsigned id) {return faction(a,id);});
        return rarePocketPopulation(role(a)==Bandit,a->GetActorBase()->IsUnique(),combat);
    }
    RE::TESObjectBOOK* bookFor(const Instance& note) const {return note.model<modelCount && note.text<textCount ? books[note.model*textCount+note.text] : nullptr;}
    unsigned pick(unsigned category) {std::vector<unsigned> choices;for (unsigned i=0;i<224;++i) if (catalog[i].category==category) choices.push_back(i);return choices[data.random.next()%choices.size()];}
    std::string signature() {constexpr std::string_view letters="ABDEGHJKLMNRSTV";std::string s;s+=letters[data.random.next()%letters.size()];s+='.';if (data.random.chance(40)) {s+=' ';s+=letters[data.random.next()%letters.size()];s+='.';}return s;}
    std::optional<std::uint32_t> create(unsigned index,RE::TESObjectREFR* owner,Purpose purpose,RE::Actor* sender=nullptr,std::string sign={},std::string shop={}) {
        if (index>=224 || !books[index] || !owner || data.notes.size()>=1000000 || data.serials[index]==65535) {logger::error("Note creation stopped: missing owner/form or persistence limit");return {};}
        Instance n;n.text=std::uint16_t(index);n.model=std::uint8_t(data.random.next()%modelCount);auto* book=bookFor(n);if (!book) return {};n.uid=++data.serials[index];n.extraBase=owner->GetFormID();n.extraUID=n.uid;n.owner=owner->GetFormID();n.sender=sender ? sender->GetFormID() : 0;n.purpose=purpose;
        n.body=replace(std::string(catalog[index].body),"{player_name}",RE::PlayerCharacter::GetSingleton()->GetName());n.body=replace(n.body,"{shop}",shop.empty() ? "your shop" : shop);
        n.signature=catalog[index].signature.empty() ? "" : sign.empty() ? signature() : sign;
        auto* extra=allocateRuntimeExtraData<RE::ExtraDataList>([](std::size_t bytes) {return RE::malloc(bytes);},[](void* storage) {::new(storage) RE::ExtraDataList();});
        if (!extra) {logger::error("Note item-data allocation failed");return {};}
        auto id=key(n);data.notes.emplace(id,n);
        extra->Add(new RE::ExtraUniqueID(n.extraBase,n.uid));
        const auto identities=[&] {
            std::vector<NoteIdentity> result;
            auto inventory=owner->GetInventory([&](RE::TESBoundObject& object) {return &object==book;});
            auto entry=inventory.find(book);
            if (entry!=inventory.end() && entry->second.first>0 && entry->second.second && entry->second.second->extraLists)
                for (auto* list:*entry->second.second->extraLists) if (list)
                    if (auto* identity=list->GetByType<RE::ExtraUniqueID>()) result.emplace_back(identity->baseID,identity->uniqueID);
            return result;
        };
        const auto before=identities();
        owner->AddObjectToContainer(book,extra,1,nullptr);
        // Skyrim may replace an instance ID during insertion. Apply that event
        // before verification; never discard the body/signature under the old ID.
        flushUniqueChanges();
        if (!find(owner,data.notes.at(id))) if (auto identity=insertedIdentity(before,identities())) {
            auto& saved=data.notes.at(id);saved.extraBase=identity->first;saved.extraUID=identity->second;
        }
        if (!find(owner,data.notes.at(id))) {
            data.notes.erase(id);
            logger::warn("Could not verify {} instance {} in {:08X}; leaving generation retryable",catalog[index].id,n.uid,n.owner);
            return {};
        }
        logger::info("Added {} instance {} to {:08X}",catalog[index].id,n.uid,n.owner);return id;
    }
    RE::ExtraDataList* find(RE::TESObjectREFR* owner,const Instance& n) const {
        auto* book=bookFor(n);if (!owner || !book) return nullptr;
        auto inv=owner->GetInventory([&](RE::TESBoundObject& o) {return &o==book;});
        auto it=inv.find(book);if (it==inv.end() || it->second.first<=0 || !it->second.second || !it->second.second->extraLists) return nullptr;
        for (auto* x:*it->second.second->extraLists) if (x) {auto* u=x->GetByType<RE::ExtraUniqueID>();if (u && u->baseID==n.extraBase && u->uniqueID==n.extraUID) return x;}return nullptr;
    }
    bool transfer(std::uint32_t id,RE::TESObjectREFR* from,RE::TESObjectREFR* to) {
        auto it=data.notes.find(id);if (it==data.notes.end()) return false;auto* extra=find(from,it->second);if (!extra) return false;
        from->RemoveItem(bookFor(it->second),1,RE::ITEM_REMOVE_REASON::kRemove,extra,to);it->second.owner=to ? to->GetFormID() : 0;return true;
    }
    bool sendPlayer(std::uint32_t id,RE::TESObjectREFR* from) {
        if (!container || !itemCount || !transfer(id,from,container)) return false;
        data.notes.at(id).purpose=Purpose::ToPlayer;
        notifyCourier();
        logger::info("Queued player letter {:08X} in vanilla courier container",id);return true;
    }
    void notifyCourier() {
        if (notificationOutstanding && itemCount->value<=0) return;
        auto* vm=RE::BSScript::Internal::VirtualMachine::GetSingleton();
        const auto handle=vm->GetObjectHandlePolicy()->GetHandleForObject(playerQuest->GetFormType(),playerQuest);
        RE::BSTSmartPointer<RE::BSScript::IStackCallbackFunctor> callback;
        if (!vm->DispatchMethodCall(handle,"WICourierScript","incrementItemCount",RE::MakeFunctionArguments(),callback)) {
            logger::error("Vanilla courier notification failed; letter remains safely in the courier container");
        } else notificationOutstanding=true;
    }
    void directPlayerLetter(unsigned category,RE::Actor* sender,std::string sign,std::string shop={}) {
        if (auto id=create(pick(category),container,Purpose::ToPlayer,sender,std::move(sign),std::move(shop))) {notifyCourier();logger::info("Player letter queued {:08X}",*id);}
    }
    int relationship(RE::Actor* a) const {
        RE::TESConditionItem item;item.data.functionData.function=RE::FUNCTION_DATA::FunctionID::kGetRelationshipRank;
        item.data.functionData.params[0]=RE::PlayerCharacter::GetSingleton();item.data.flags.opCode=RE::CONDITION_ITEM_DATA::OpCode::kEqualTo;
        RE::ConditionCheckParams params(a,RE::PlayerCharacter::GetSingleton());
        for (int rank=-4;rank<=4;++rank) {item.data.comparisonValue.f=static_cast<float>(rank);if (item.IsTrue(params)) return rank;}return 0;
    }
    RE::Actor* spouse() const {if (!marriage || !marriage->IsRunning()) return nullptr;auto ref=marriage->GetAliasedRef(0).get();return ref ? ref->As<RE::Actor>() : nullptr;}
    void playerLetters(RE::Actor* a,ActorState& s,double day) {
        if (!a->GetActorBase()->IsUnique()) return;
        // Relationships can change independently of letter due dates. Re-evaluate at
        // most once per ten real seconds, without changing persisted game-day timers.
        const auto real=std::chrono::steady_clock::now();auto& checked=relationshipChecks[a->GetFormID()];
        if (!repeatNotes && checked.time_since_epoch().count() && real-checked<10s) return;
        checked=real;
        auto* partner=spouse();const auto rank=relationship(a);
        const std::array<bool,4> allowed{a==partner,partner && a!=partner && rank==4,rank>=1 && a!=partner,rank==-1 || rank==-2};
        constexpr std::array<double,4> low{3,14,5,7},high{5,21,7,14};constexpr std::array<unsigned,4> odds{5,1,2,1};
        constexpr std::array<unsigned,4> categories{8,9,11,12};
        for (unsigned i=0;i<4;++i) {
            if (!allowed[i]) continue;if (s.playerDue[i]<0) {s.playerDue[i]=day+data.random.days(low[i],high[i]);continue;}if (day<s.playerDue[i]) continue;
            s.playerDue[i]=day+data.random.days(low[i],high[i]);if (!data.random.letterChance(odds[i])) continue;
            if (i==3) {if (!canStageHate(data,a->GetFormID())) continue;if (auto id=create(pick(categories[i]),a,Purpose::HateDraft,a,a->GetName())) data.notes.at(*id).due=day+data.random.days(2,3);}
            else {std::string sign=i==0 ? first(a->GetName()) : i==1 ? initial(a->GetName()) : data.random.chance(50) ? a->GetName() : initial(a->GetName());directPlayerLetter(categories[i],a,std::move(sign));}
        }
    }
    void recoverQueuedNPCNotes() {
        std::vector<std::pair<unsigned,unsigned>> pending;
        for (const auto& [id,note]:data.notes) if (auto recipient=legacyPocketRecipient(data,id,courier->GetFormID())) pending.emplace_back(id,*recipient);
        for (auto [noteID,recipientID]:pending) {
            auto it=data.notes.find(noteID);auto* recipient=RE::TESForm::LookupByID<RE::Actor>(recipientID);
            if (it==data.notes.end() || !recipient || recipient->IsDeleted()) continue;
            // Never create a replacement: move the tracked physical copy or recognize its prior arrival.
            bool recovered=false;
            if (find(recipient,it->second)) {it->second.owner=recipientID;recovered=true;logger::info("Recovered already-delivered NPC note {:08X} for {:08X}",noteID,recipientID);}
            else if (find(courier,it->second) && transfer(noteID,courier,recipient)) {recovered=true;logger::info("Migrated queued NPC note {:08X} directly to {:08X}",noteID,recipientID);}
            if (recovered) if (auto state=data.actors.find(recipientID);state!=data.actors.end() && state->second.pocket==noteID) state->second.refresh=now()+data.random.days(3,5);
        }
    }
    void debugPlayerDelivery() {
        if (!config.debug) {report("Notes and Letters: run NLDebug first, then NLDeliverPlayerNote.");return;}
        if (!active || !valid || !formsReady) {report(inactiveReason());return;}
        flush();auto* player=RE::PlayerCharacter::GetSingleton();if (!player || !player->Is3DLoaded()) {report("Notes and Letters: load a playable save first.");return;}
        std::vector<unsigned> choices;for (unsigned i=0;i<catalog.size();++i) if (catalog[i].category>=8) choices.push_back(i);
        const unsigned index=choices[data.random.next()%choices.size()];
        auto note=create(index,container,Purpose::ToPlayer,nullptr,signature(),"a local shop");
        if (!note) {report("Notes and Letters: test letter could not be created.");return;}
        notifyCourier();
        // Test-only dispatch attempt. Never stop/reset an existing player delivery or change permanent conditions.
        const bool running=playerQuest->IsRunning();
        const bool started=running || playerQuest->Start();
        if (started) {
            if (!running) {courier->MoveTo(player);courier->Enable(false);}
            if (auto* actor=courier->As<RE::Actor>()) actor->EvaluatePackage();
        }
        report(fmt::format("Notes and Letters: test player letter '{}' queued ({:08X}). {} Close the console; if the courier is not dispatched yet, enter a settlement/change location.",catalog[index].title,*note,started ? "Vanilla courier quest active." : "Vanilla dispatch is pending."));
    }
    void visit(RE::Actor* a,bool relationships=true) {
        if (!eligible(a)) return;const auto id=a->GetFormID();if (data.actors.size()>=100000 && !data.actors.contains(id)) return;
        auto& s=data.actors[id];double day=now();
        if (s.pocket && legacyPocketRecipient(data,s.pocket,courier->GetFormID())) {if (relationships) playerLetters(a,s,day);return;}
        logger::debug("NPC check {:08X}: role={}, refresh={}, day={}, outstanding={}",id,unsigned(role(a)),s.refresh,day,s.pocket);
        if (npcRefreshDue(s,day,repeatNotes)) {
            s.refresh=day+data.random.days(3,5);
            if (s.pocket) {
                auto it=data.notes.find(s.pocket);
                auto* owner=it==data.notes.end() ? nullptr : it->second.owner==id ? static_cast<RE::TESObjectREFR*>(a) : it->second.owner==courier->GetFormID() ? courier : nullptr;
                if (!owner || !find(owner,it->second)) s.pocket=0;
                else if (owner==a && (repeatNotes || data.random.chance(50))) {if (transfer(s.pocket,owner,nullptr)) s.pocket=0;}
            }
            if (!s.pocket) if (auto category=repeatNotes ? std::optional<unsigned>(forcedNPCCategory(data.random,role(a))) : rollNPC(data.random,role(a),rarerPocketNPC(a))) {
                logger::debug("NPC roll succeeded {:08X}: category={}, direct inventory",id,*category);
                if (auto note=create(pick(*category),a,Purpose::Pocket)) {s.pocket=*note;data.notes.at(*note).sender=id;}
            }
        }
        if (relationships) playerLetters(a,s,day);
    }
    static void report(const std::string& text) {logger::info("{}",text);if (auto* console=RE::ConsoleLog::GetSingleton()) console->Print("%s",text.c_str());}
    void setDebug(bool enabled) {config.debug=enabled;if (!enabled && repeatNotes) {repeatNotes=false;}spdlog::set_level(enabled ? spdlog::level::debug : spdlog::level::info);spdlog::flush_on(enabled ? spdlog::level::debug : spdlog::level::warn);report(enabled ? "Notes and Letters: debug mode ON" : "Notes and Letters: debug mode OFF");}
    void toggleRepeat() {
        if (!config.debug) {report("Notes and Letters: enable debug mode with NLDebug first.");return;}
        if (!active || !valid || !formsReady) {report(inactiveReason());return;}
        repeatNotes=!repeatNotes;
        if (!repeatNotes) {report("Notes and Letters: repeat mode OFF. Normal NPC chances and refresh delays resume.");return;}
        report("Notes and Letters: repeat mode ON. NPC rolls are forced with zero refresh delay; notes go directly into NPC inventories.");
    }
    void debugSpawn() {
        if (!config.debug) {report("Notes and Letters: run NLDebug to enable debug mode first.");return;}
        if (!active || !valid) {report(inactiveReason());return;}
        flush();recoverQueuedNPCNotes();auto target=debugTarget.get();
        if (!target) if (auto* crosshair=RE::CrosshairPickData::GetSingleton()) target=crosshair->GetActiveTarget().get();
        auto* actor=target ? target->As<RE::Actor>() : nullptr;
        if (!eligible(actor) || !actor->Is3DLoaded()) {report("Notes and Letters: aim at an eligible living adult NPC, then open the console.");return;}
        const auto actorID=actor->GetFormID();if (data.actors.size()>=100000 && !data.actors.contains(actorID)) {report("Notes and Letters: actor persistence limit reached.");return;}
        auto& state=data.actors[actorID];
        if (state.pocket) {
            auto n=data.notes.find(state.pocket);auto* owner=n==data.notes.end() ? nullptr : RE::TESForm::LookupByID<RE::TESObjectREFR>(n->second.owner);
            if (n==data.notes.end() || !owner || !find(owner,n->second)) state.pocket=0;
            else if (owner!=actor && owner!=courier) state.pocket=0;
        }
        if (!debugSpawnAllowed(config.debug,active,eligible(actor),state.pocket!=0)) {report("Notes and Letters: this NPC already has an outstanding pocket note (including queued deliveries).");return;}
        const auto occupation=role(actor);const auto category=forcedNPCCategory(data.random,occupation);const auto index=pick(category);
        auto* owner=static_cast<RE::TESObjectREFR*>(actor);
        if (auto id=create(index,owner,Purpose::Pocket)) {
            state.pocket=*id;data.notes.at(*id).sender=actorID;state.refresh=now()+data.random.days(3,5);
            report(fmt::format("Notes and Letters: '{}' created to {} ({:08X}); category {}, role {}, refresh day {:.3f}.",catalog[index].title,actor->GetName(),actorID,category,unsigned(occupation),state.refresh));
        } else report("Notes and Letters: note creation failed; see NotesAndLetters.log.");
    }
    RE::BSEventNotifyControl ProcessEvent(const SKSE::CrosshairRefEvent* event,RE::BSTEventSource<SKSE::CrosshairRefEvent>*) override {
        auto* ui=RE::UI::GetSingleton();if (event && ui && !ui->IsMenuOpen(RE::Console::MENU_NAME)) debugTarget=event->crosshairRef ? event->crosshairRef->CreateRefHandle() : RE::ObjectRefHandle{};
        return RE::BSEventNotifyControl::kContinue;
    }
    void flushUniqueChanges() {
        std::vector<UniqueChange> changed;
        {std::scoped_lock lock(inboxMutex);changed.swap(uniqueChanges);}
        for (auto e:changed) {
            auto it=std::find_if(books.begin(),books.end(),[e](auto* b) {return b && b->GetFormID()==e.book;});if (it==books.end()) continue;
            const auto index=unsigned(it-books.begin())%textCount;
            for (auto& [id,n]:data.notes) if (bookFor(n)==*it && rebind(n,index,e.oldBase,e.oldUID,e.newBase,e.newUID)) break;
        }
    }
    void flush() {
        flushUniqueChanges();
        std::vector<Movement> moved;std::vector<unsigned> invested;
        {std::scoped_lock lock(inboxMutex);moved.swap(movements);invested.swap(investments);}
        for (auto e:moved) {
            auto it=std::find_if(books.begin(),books.end(),[e](auto* b) {return b && b->GetFormID()==e.book;});if (it==books.end()) continue;
            auto* destination=e.newOwner ? RE::TESForm::LookupByID<RE::TESObjectREFR>(e.newOwner) : nullptr;
            for (auto& [id,n]:data.notes) if (n.text==unsigned(it-books.begin())%textCount && bookFor(n)==*it && n.owner==e.oldOwner && (n.extraUID==e.uid || (destination && find(destination,n)))) {
                n.owner=e.newOwner;if (e.newOwner==0x14) n.purpose=Purpose::Delivered;
            }
        }
        for (auto id:invested) {auto& s=data.actors[id];if (!s.investmentSeen) {s.investmentSeen=true;s.investmentDue=now()+data.random.days(2,3);auto* a=RE::TESForm::LookupByID<RE::Actor>(id);auto* cell=a ? a->GetParentCell() : nullptr;s.shop=cell && cell->IsInteriorCell() ? cell->GetName() : a ? std::string(a->GetName())+"'s trade" : "the shop";logger::info("Investment observed for {:08X}",id);}}
    }
    void delayedLetters() {
        std::vector<unsigned> drafts;for (const auto& [id,n]:data.notes) if (n.purpose==Purpose::HateDraft && now()>=n.due) drafts.push_back(id);
        for (auto id:drafts) {auto& n=data.notes.at(id);auto* actor=RE::TESForm::LookupByID<RE::Actor>(n.sender);
            if (!readyHate(n,now(),actor && find(actor,n),actor && !actor->IsDead())) {n.purpose=Purpose::Delivered;continue;}sendPlayer(id,actor);
        }
        std::vector<unsigned> due;for (auto& [id,s]:data.actors) if (s.investmentDue>=0 && now()>=s.investmentDue) {s.investmentDue=-1;if (data.random.letterChance(20)) due.push_back(id);}
        for (auto id:due) if (auto* a=RE::TESForm::LookupByID<RE::Actor>(id);a && !a->IsDead()) {
            std::string shop=data.actors.at(id).shop;
            directPlayerLetter(10,a,std::string(a->GetName())+", "+shop,shop);
        }
    }
    void bundles(bool repair=false) {
        if (!courier) return;
        const double day=now();
        if (!repair && day<data.bundleDue) return;
        std::vector<unsigned> carried;
        for (auto& [id,note]:data.notes) if (note.purpose==Purpose::Bundle && note.owner==courier->GetFormID()) {
            if (find(courier,note)) carried.push_back(id);
            else note.owner=0;
        }
        const bool refresh=day>=data.bundleDue;
        if (refresh) {
            for (auto id:carried) transfer(id,courier,nullptr);
            carried.clear();
            // Failed removals remain counted, so refreshing cannot stack bundles.
            for (const auto& [id,note]:data.notes)
                if (note.purpose==Purpose::Bundle && note.owner==courier->GetFormID() && find(courier,note))
                    carried.push_back(id);
        }
        const unsigned target=courierBundleTarget(unsigned(carried.size()),unsigned(data.random.next()%3));
        unsigned added=0;
        for (unsigned i=unsigned(carried.size());i<target;++i)
            if (create(pick(unsigned(data.random.next()%8)),courier,Purpose::Bundle)) ++added;
        const auto total=carried.size()+added;
        data.bundleDue=total>=2 ? day+data.random.days(3,5) : day+1.0/24.0;
        logger::info("Courier pocket bundle verified: {} notes; delivery quest independent",total);
    }
    void houseLetters(const std::vector<RE::Actor*>& actors) {
        auto* player=RE::PlayerCharacter::GetSingleton();unsigned owned=0;
        for (unsigned i=0;i<7;++i) if (homes[i]) {
            auto* owner=homes[i]->GetOwner();bool isOwned=owner==player->GetActorBase();
            if (auto* f=owner ? owner->As<RE::TESFaction>() : nullptr) isOwned=player->IsInFaction(f);
            if (isOwned) owned|=1u<<i;
        }
        if (!data.homesInitialized) {data.homesSeen=std::uint8_t(owned);data.homesInitialized=true;}
        // Existing homes count on first activation too; each home receives only one lifetime roll.
        data.homesSeen|=std::uint8_t(owned);
        for (unsigned i=0;i<7;++i) if ((data.homesSeen&(1u<<i)) && !(data.homesProcessed&(1u<<i))) {
            auto* loc=homes[i] ? settlement(homes[i]->GetLocation()) : nullptr;if (!loc) continue;
            std::vector<RE::Actor*> locals;
            for (auto* a:actors) if (eligible(a) && a->GetActorBase()->IsUnique() && settlement(a->GetEditorLocation())==loc && a!=spouse()) locals.push_back(a);
            if (locals.empty()) continue;auto* sender=locals[data.random.next()%locals.size()];
            data.homesProcessed|=std::uint8_t(1u<<i);data.houseSenders[i]=sender->GetFormID();const unsigned amount=houseLetterCount(data.random);
            std::vector<unsigned> choices;for (unsigned j=0;j<224;++j) if (catalog[j].category==13+i) choices.push_back(j);
            if (data.random.chance(50)) std::reverse(choices.begin(),choices.end());
            for (unsigned j=0;j<amount;++j) {std::string sign=data.random.chance(50) ? sender->GetName() : initial(sender->GetName());if (create(choices[j],container,Purpose::ToPlayer,sender,sign)) notifyCourier();}
        }
    }
    void discoverActorsAtLoad() {
        const auto start=std::chrono::steady_clock::now();
        // References are already registered. Do not request cells or 3D.
        for (auto cellID:discoveryCells) if (auto* cell=RE::TESForm::LookupByID<RE::TESObjectCELL>(cellID))
            cell->ForEachReference([this](RE::TESObjectREFR* ref) {
                if (auto* actor=ref ? ref->As<RE::Actor>() : nullptr) rememberActor(actor->GetFormID());
                return RE::BSContainer::ForEachResult::kContinue;
            });
        if (auto* processes=RE::ProcessLists::GetSingleton())
            processes->ForEachHighActor([this](RE::Actor* actor) {
                if (actor) {rememberActor(actor->GetFormID());highActors.insert(actor->GetFormID());actorWork.add(actor->GetFormID());}
                return RE::BSContainer::ForEachResult::kContinue;
            });
        bundles(true);
        logger::info("Save-load note discovery: {} known actors in {:.3f} ms; Loading Menu open={}",knownActors.size(),
            std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count(),
            RE::UI::GetSingleton()->IsMenuOpen(RE::LoadingMenu::MENU_NAME));
    }
    void scan() {
        auto* player=RE::PlayerCharacter::GetSingleton();if (!player || !player->Is3DLoaded() || !RE::UI::GetSingleton() || RE::UI::GetSingleton()->GameIsPaused()) return;
        const auto start=std::chrono::steady_clock::now();
        if (start>=nextMaintenance) {
            nextMaintenance=start+2500ms;flush();recoverQueuedNPCNotes();
            if (itemCount->value>0) notificationOutstanding=false;
            else if (std::any_of(data.notes.begin(),data.notes.end(),[this](const auto& row) {return row.second.purpose==Purpose::ToPlayer && row.second.owner==container->GetFormID();})) notifyCourier();
            std::vector<RE::Actor*> actors;
            const bool relationshipPass=start>=nextRelationships;
            if (relationshipPass) nextRelationships=start+10s;
            for (auto id:highActors) if (auto* actor=RE::TESForm::LookupByID<RE::Actor>(id);actor && actor->Is3DLoaded()) {
                actors.push_back(actor);
                const auto found=data.actors.find(id);
                if (repeatNotes || found==data.actors.end() || npcRefreshDue(found->second,now(),false) || relationshipPass)
                    actorWork.add(id);
            }
            if (auto* actor=spouse()) {
                rememberActor(actor->GetFormID());
                if (relationshipPass) actorWork.add(actor->GetFormID());
            }
            delayedLetters();bundles();houseLetters(actors);
        }
        unsigned processed=0;
        // Bound expensive visits by count AND elapsed time. Never enqueue a
        // continuation from a task: SKSE may drain it in the same frame.
        while (processed<4 && !actorWork.empty() && std::chrono::steady_clock::now()-start<2ms) {
            const auto id=actorWork.pop();visit(RE::TESForm::LookupByID<RE::Actor>(id));++processed;
        }
        if (start>=nextRemote && std::chrono::steady_clock::now()-start<2ms) {
            nextRemote=start+250ms;
            for (unsigned i=0;i<4 && i<remoteActors.size() && std::chrono::steady_clock::now()-start<2ms;++i) {
                if (remoteCursor>=remoteActors.size()) remoteCursor=0;
                const auto id=remoteActors[remoteCursor++];
                if (highActors.contains(id)) continue;
                const auto found=data.actors.find(id);
                if (!repeatNotes && found!=data.actors.end() && !npcRefreshDue(found->second,now(),false)) continue;
                if (auto* actor=RE::TESForm::LookupByID<RE::Actor>(id)) visit(actor,false);
            }
        }

        const auto elapsed=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
        if (elapsed>=5.0) logger::warn("Slow note work slice: {:.2f} ms; loaded visits={}, known actors={}, discovery cell={}/{}",elapsed,processed,remoteActors.size(),cellCursor,discoveryCells.size());
    }
    std::string description(RE::TESObjectBOOK* b,RE::ExtraDataList* extras) {
        flushUniqueChanges();
        auto it=std::find(books.begin(),books.end(),b);if (it==books.end() || !extras) return {};
        auto* uid=extras->GetByType<RE::ExtraUniqueID>();if (!uid) return {};
        auto n=std::find_if(data.notes.begin(),data.notes.end(),[&](const auto& row) {return row.second.text==unsigned(it-books.begin())%textCount && bookFor(row.second)==b && row.second.extraBase==uid->baseID && row.second.extraUID==uid->uniqueID;});if (n==data.notes.end()) {
            // Repair only the exact opened instance; do not add another inventory item.
            const auto index=unsigned(it-books.begin())%textCount;
            if (!uid->uniqueID || data.serials[index]==65535 || data.notes.size()>=1000000) return {};
            Instance repaired;repaired.text=std::uint16_t(index);repaired.model=std::uint8_t(unsigned(it-books.begin())/textCount);
            repaired.uid=++data.serials[index];repaired.extraBase=uid->baseID;repaired.extraUID=uid->uniqueID;
            repaired.body=replace(std::string(catalog[index].body),"{player_name}",RE::PlayerCharacter::GetSingleton()->GetName());
            repaired.body=replace(repaired.body,"{shop}","your shop");
            repaired.signature=catalog[index].signature.empty() ? "" : signature();
            auto* player=RE::PlayerCharacter::GetSingleton();
            if (find(player,repaired)) {repaired.owner=player->GetFormID();repaired.purpose=Purpose::Delivered;}
            else if (find(courier,repaired)) {repaired.owner=courier->GetFormID();repaired.purpose=Purpose::Bundle;}
            else return {}; // Unknown owner: leave the instance unchanged.
            n=data.notes.emplace(key(repaired),std::move(repaired)).first;
            logger::info("Recovered opened note {} instance {}; signature saved",catalog[index].id,n->second.uid);
        }
        std::string s="<font face='$HandwrittenFont'><p align='left'>"+escaped(n->second.body);
        s+=signatureFooter(escaped(n->second.signature));return s+"</p></font>";
    }
    RE::BSEventNotifyControl ProcessEvent(const RE::TESObjectLoadedEvent* e,RE::BSTEventSource<RE::TESObjectLoadedEvent>*) override {
        if (e && active) {const auto id=e->formID;const bool loaded=e->loaded;queue([this,id,loaded] {
            if (!loaded) {highActors.erase(id);return;}
            if (RE::TESForm::LookupByID<RE::Actor>(id)) {
                rememberActor(id);highActors.insert(id);actorWork.add(id);
                if (courier && id==courier->GetFormID()) bundles(true);
            }
        });}
        return RE::BSEventNotifyControl::kContinue;
    }
    RE::BSEventNotifyControl ProcessEvent(const RE::TESContainerChangedEvent* e,RE::BSTEventSource<RE::TESContainerChangedEvent>*) override {
        if (e && active && e->itemCount>0 && std::any_of(books.begin(),books.end(),[e](auto* b) {return b && b->GetFormID()==e->baseObj;})) {std::scoped_lock lock(inboxMutex);movements.push_back({e->baseObj,e->uniqueID,e->oldContainer,e->newContainer});}return RE::BSEventNotifyControl::kContinue;
    }
    RE::BSEventNotifyControl ProcessEvent(const RE::TESUniqueIDChangeEvent* e,RE::BSTEventSource<RE::TESUniqueIDChangeEvent>*) override {
        if (e && active && std::any_of(books.begin(),books.end(),[e](auto* b) {return b && b->GetFormID()==e->objectID;})) {std::scoped_lock lock(inboxMutex);uniqueChanges.push_back({e->objectID,e->oldBaseID,e->newBaseID,e->oldUniqueID,e->newUniqueID});}return RE::BSEventNotifyControl::kContinue;
    }
    RE::BSEventNotifyControl ProcessEvent(const RE::TESTrackedStatsEvent* e,RE::BSTEventSource<RE::TESTrackedStatsEvent>*) override {
        if (e && active && e->stat=="Stores Invested In") {auto* topics=RE::MenuTopicManager::GetSingleton();auto ref=topics ? topics->speaker.get() : RE::TESObjectREFRPtr{};if (!ref && topics) ref=topics->lastSpeaker.get();auto* a=ref ? ref->As<RE::Actor>() : nullptr;if (a && eligible(a)) {std::scoped_lock lock(inboxMutex);investments.push_back(a->GetFormID());}else logger::warn("Investment stat changed without a resolvable dialogue merchant; skipped rather than guessing sender");}return RE::BSEventNotifyControl::kContinue;
    }
private:
    bool formsReady=false,notificationOutstanding=false;std::atomic_bool queued{false};std::mutex inboxMutex;std::vector<Movement> movements;std::vector<UniqueChange> uniqueChanges;std::vector<unsigned> investments;std::jthread worker;
};
struct DebugCommands {
    static bool toggle(const RE::SCRIPT_PARAMETER*,RE::SCRIPT_FUNCTION::ScriptData*,RE::TESObjectREFR*,RE::TESObjectREFR*,RE::Script*,RE::ScriptLocals*,double& result,std::uint32_t&) {
        auto& m=Manager::get();m.setDebug(!m.config.debug);result=m.config.debug ? 1.0 : 0.0;return true;
    }
    static bool spawn(const RE::SCRIPT_PARAMETER*,RE::SCRIPT_FUNCTION::ScriptData*,RE::TESObjectREFR*,RE::TESObjectREFR*,RE::Script*,RE::ScriptLocals*,double& result,std::uint32_t&) {
        Manager::get().debugSpawn();result=1;return true;
    }
    static bool deliver(const RE::SCRIPT_PARAMETER*,RE::SCRIPT_FUNCTION::ScriptData*,RE::TESObjectREFR*,RE::TESObjectREFR*,RE::Script*,RE::ScriptLocals*,double& result,std::uint32_t&) {Manager::get().debugPlayerDelivery();result=1;return true;}
    static bool repeat(const RE::SCRIPT_PARAMETER*,RE::SCRIPT_FUNCTION::ScriptData*,RE::TESObjectREFR*,RE::TESObjectREFR*,RE::Script*,RE::ScriptLocals*,double& result,std::uint32_t&) {
        auto& m=Manager::get();m.toggleRepeat();result=m.repeatNotes ? 1.0 : 0.0;return true;
    }
    static bool installOne(std::string_view slot,const char* name,const char* help,RE::SCRIPT_FUNCTION::Execute_t* execute,const char* alias="") {
        // Reuse verified no-op developer slots, never a working command or another plugin's handler.
        auto* command=RE::SCRIPT_FUNCTION::LocateConsoleCommand(slot);if (!command || !command->executeFunction) {logger::error("Cannot register {}: unused console slot missing",name);return false;}
        const auto address=reinterpret_cast<std::uintptr_t>(command->executeFunction);const auto text=REL::Module::get().segment(REL::Segment::textx);
        if (address<text.address() || address+3>text.address()+text.size() || !unusedConsoleStub({reinterpret_cast<const std::uint8_t*>(address),3})) {logger::error("Cannot register {}: {} is not an untouched no-op slot",name,slot);return false;}
        auto replacement=*command;replacement.functionName=name;replacement.shortName=alias;replacement.helpString=help;replacement.referenceFunction=false;replacement.SetParameters();replacement.executeFunction=execute;replacement.conditionFunction=nullptr;
        REL::safe_write(reinterpret_cast<std::uintptr_t>(command),&replacement,sizeof(replacement));logger::info("Registered console command {} in unused {} slot",name,slot);return true;
    }
    static void install() {
        installOne("TestSeenData","NLDebug","Toggle Notes and Letters debug mode for this session",toggle);
        installOne("TestLocalMap","NLSpawnNote","Force one allowed NPC note onto the crosshair NPC (debug mode required)",spawn);
        installOne("OutputAllocations","NLDeliverPlayerNote","Force a random player letter and request vanilla courier delivery (debug mode required)",deliver,"NLDeliverNote");
        installOne("OutputMemStats","NLRepeatNotes","Toggle zero-delay direct NPC note repeat testing (debug mode required)",repeat);
    }
};
struct BookHook {
    static inline REL::Relocation<RE::UI_MESSAGE_RESULTS(*)(RE::BookMenu*,RE::UIMessage&)> original;
    static RE::UI_MESSAGE_RESULTS process(RE::BookMenu* self,RE::UIMessage& message) {
        // The engine populates these globals before kShow. Later/hide messages may
        // retain stale instance data; do not dereference it on those paths.
        if (Manager::get().active && message.type==RE::UI_MESSAGE_TYPE::kShow) {
            auto* book=RE::BookMenu::GetTargetForm();
            const auto& owned=Manager::get().books;
            if (book && std::find(owned.begin(),owned.end(),book)!=owned.end()) {
                logger::info("Opening note {:08X}; inventory art={}",book->GetFormID(),book->inventoryModel!=nullptr);
                auto text=Manager::get().description(book,RE::BookMenu::GetExtraList());
                if (!text.empty()) RE::BookMenu::GetDescription()=text.c_str();
                else logger::warn("No instance text available for {:08X}; retaining base note text",book->GetFormID());
            }
        }
        auto result=original(self,message);
        return result;
    }
    static void install() {REL::Relocation<std::uintptr_t> v{RE::VTABLE_BookMenu[0]};original=v.write_vfunc(4,process);}
};
void save(SKSE::SerializationInterface* api) {auto& m=Manager::get();m.flush();auto bytes=encode(m.data);if (!api->OpenRecord(recordID,m.valid ? 2u : 0xFFFFFFFFu) || !api->WriteRecordData(bytes.data(),std::uint32_t(bytes.size()))) logger::error("Notes save failed");}
void load(SKSE::SerializationInterface* api) {
    auto& m=Manager::get();m.reset();unsigned type,version,length;bool seen=false;
    while (api->GetNextRecordInfo(type,version,length)) {if (type!=recordID) continue;if (seen || (version!=1 && version!=2 && version!=0xFFFFFFFFu) || length>128*1024*1024) {m.valid=false;continue;}seen=true;std::vector<std::uint8_t> bytes(length);if (api->ReadRecordData(bytes.data(),length)!=length) {m.valid=false;continue;}auto decoded=decode(bytes,version==0xFFFFFFFFu ? 1u : version);if (!decoded) {m.valid=false;continue;}if (version==0xFFFFFFFFu) {if (!emptyLegacyState(*decoded)) {m.valid=false;logger::error("Nonempty invalid legacy note state refused");continue;}logger::warn("Recovered empty legacy disabled state; no notes or timers existed");}m.data=std::move(*decoded);
        auto resolve=[api](unsigned id) {unsigned out=0;if (id) api->ResolveFormID(id,out);return out;};
        std::unordered_map<unsigned,ActorState> remapped;for (auto [id,s]:m.data.actors) if (auto newID=resolve(id)) remapped.emplace(newID,s);m.data.actors=std::move(remapped);
        for (auto& [id,n]:m.data.notes) {n.owner=resolve(n.owner);n.sender=resolve(n.sender);n.extraBase=resolve(n.extraBase);}
        m.data.courierTarget=resolve(m.data.courierTarget);for (auto& id:m.data.houseSenders) id=resolve(id);
    }
}
void revert(SKSE::SerializationInterface*) {Manager::get().reset();}
void message(SKSE::MessagingInterface::Message* e) {
    auto& m=Manager::get();switch (e->type) {
    case SKSE::MessagingInterface::kDataLoaded:m.initialize();BookHook::install();DebugCommands::install();break;
    case SKSE::MessagingInterface::kPreLoadGame:m.repeatNotes=false;m.debugTarget={};m.active=false;++m.session;break;
    case SKSE::MessagingInterface::kPostLoadGame:if (e->data) m.enter();break;
    case SKSE::MessagingInterface::kNewGame:m.reset();m.enter();break;
    default:break;
    }
}
}
SKSEPluginLoad(const SKSE::LoadInterface* skse) {
    SKSE::Init(skse);if (auto path=SKSE::log::log_directory()) {auto sink=std::make_shared<spdlog::sinks::basic_file_sink_mt>((*path/"NotesAndLetters.log").string(),true);spdlog::set_default_logger(std::make_shared<spdlog::logger>("NotesAndLetters",std::move(sink)));spdlog::set_level(spdlog::level::info);spdlog::flush_on(spdlog::level::warn);spdlog::flush_every(3s);}
    logger::info("Notes and Letters 1.1.2 development build; runtime {}",REL::Module::get().version().string());
    const auto version=REL::Module::get().version();const std::set<unsigned> ae{317,318,323,342,353,629,640,659,1130,1170,1179};
    if (!(version.major()==1 && ((version.minor()==5 && version.patch()==97) || (version.minor()==6 && ae.contains(version.patch())) || (version.minor()==7 && (version.patch()==99 || version.patch()==104))))) {logger::error("Unsupported runtime");return false;}
    auto* api=SKSE::GetSerializationInterface();if (!api || !SKSE::GetTaskInterface()) return false;
    api->SetUniqueID(saveID);api->SetSaveCallback(save);api->SetLoadCallback(load);api->SetRevertCallback(revert);return SKSE::GetMessagingInterface()->RegisterListener(message);
}
